# PIP-Net with a DINO ViT backbone, on CUB-200-2011

This is [M-Nauta/PIPNet](https://github.com/M-Nauta/PIPNet) (CVPR 2023) with the CNN
backbone swapped for a self-supervised **DINO / DINOv2 Vision Transformer**, plus the
plumbing needed to run it on a server against an existing CUB directory.

Everything upstream still works unchanged — `--net convnext_tiny_26` behaves exactly as
before. The DINO path is additive.

---

## 1. What changed

| File | Change |
|---|---|
| `features/dino_features.py` | **New.** `DINOViTFeatures` wraps a timm ViT so it emits `(B, C, H, W)` like a CNN trunk: runs `forward_features`, drops the CLS (and DINOv2 register) tokens, reshapes the patch tokens back onto their grid. Six backbones registered. |
| `pipnet/pipnet.py` | Registers the DINO backbones; `get_network` reads the width from `features.out_channels` instead of hunting for the last `Conv2d`, and inserts a learnable 1×1 conv before the prototype softmax for ViT backbones (see §5). |
| `util/args.py` | New `--data_dir`, `--cub_layout`, `--dino_*`, `--patch_size_vis`, `--disable_ood_eval`, `--disable_cub_parts_eval`, `--no_redirect_output`. `get_optimizer_nn` gained a DINO branch that splits transformer blocks into the same three lr tiers the ResNet/ConvNeXt branches use. |
| `util/data.py` | CUB paths are no longer hardcoded. `--data_dir` sets the root and `--cub_layout` picks between the two directory layouts below. |
| `util/func.py` | `get_patch_size` honours `--patch_size_vis` (default unchanged at 32px). |
| `main.py` | Visualises pretrained prototypes for ViT backbones too; skips the CUB part-purity stage when the annotation files are absent instead of crashing after a full run; skips missing OOD datasets; `--no_redirect_output`. Two upstream bugs fixed along the way — see below. |
| `check_setup.py` | **New.** Preflight check: packages, GPU, dataset layout, DINO weight download. Run it before a long job. |
| `run_cub_dino.sh` | **New.** Launcher with `default` / `lowmem` / `hires` / `eval` presets. |

Two upstream bugs surfaced while testing and are fixed here:

- `CosineAnnealingWarmRestarts(..., verbose=False)` crashed the second training phase on
  PyTorch ≥ 2.7, which removed the long-deprecated `verbose` argument. Training died right
  after pretraining finished.
- `epoch` was undefined when running with `--epochs 0`, which is the checkpoint-evaluation
  mode the upstream README documents; the part-purity and OOD stages then raised
  `NameError`.
- `util/vis_pipnet.py` built an output filename with `path.split('/')[-1]`, which only
  strips the directory on POSIX. Now uses `os.path.basename`. Linux-only runs were never
  affected; this just makes the code portable.

Exact diff against upstream: `git diff HEAD` inside this folder.

### Backbones available

| `--net` | timm weights | Channels | Grid @224 | Grid @448 |
|---|---|---|---|---|
| `dino_vitb16` *(default choice)* | `vit_base_patch16_224.dino` | 768 | 14×14 | 28×28 |
| `dino_vits16` | `vit_small_patch16_224.dino` | 384 | 14×14 | 28×28 |
| `dino_vitb8` | `vit_base_patch8_224.dino` | 768 | 28×28 | 56×56 |
| `dinov2_vitb14` | `vit_base_patch14_dinov2.lvd142m` | 768 | 16×16 | 32×32 |
| `dinov2_vits14` | `vit_small_patch14_dinov2.lvd142m` | 384 | 16×16 | 32×32 |
| `dinov2_vitb14_reg` | `vit_base_patch14_reg4_dinov2.lvd142m` | 768 | 16×16 | 32×32 |

`dino_vitb16` matches the backbone your INTR / PromptCAM configs use
(`pretrained_weights: vit_base_patch16_dino`), so results are comparable across methods.

---

## 2. Setup on tetra

```bash
# ship it over
scp PIPNet_dino_cub.tgz  <user>@tetra:~/
ssh <user>@tetra
tar xzf PIPNet_dino_cub.tgz && cd PIPNet_dino_cub

# environment (conda or venv, either is fine)
conda create -n pipnet_dino python=3.10 -y && conda activate pipnet_dino
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
pip install -r requirements.txt
```

The DINO weights are pulled from the HuggingFace hub the first time you run
(~330MB for ViT-B/16) and cached in `~/.cache/huggingface`. To pre-warm the cache, or to
check the node has outbound network:

```bash
python3 -c "import timm; timm.create_model('vit_base_patch16_224.dino', pretrained=True); print('weights cached OK')"
```

If the compute node is offline, download that on a networked box and either copy
`~/.cache/huggingface` across, or pass a local checkpoint with `--dino_ckpt /path/to.pth`.

Then confirm everything lines up before committing to a multi-hour job:

```bash
python3 check_setup.py --data_dir /home/paul/Paul/DATASETS/CUB --cub_layout imagefolder
```

It prints package versions, visible GPUs and free memory, the resolved dataset
directories with class and image counts, and the resulting prototype grid size. It exits
non-zero if anything is wrong.

---

## 3. Data

Two layouts are supported. Pick with `--cub_layout`.

**`imagefolder`** — a plain train/val split, which is what
`/home/paul/Paul/DATASETS/CUB` already is:

```
CUB/
├── train/001.Black_footed_Albatross/*.jpg
│        002.Laysan_Albatross/*.jpg  ...
└── val/  001.Black_footed_Albatross/*.jpg   (or test/)
```

Nothing to preprocess. Run with `--data_dir /home/paul/Paul/DATASETS/CUB --cub_layout imagefolder`.

**`pipnet`** — the four folders the paper uses, produced from the raw CUB-200-2011
release by `util/preprocess_cub.py` (edit `path` at the top of that file first):

```
CUB_200_2011/
├── images.txt, bounding_boxes.txt, train_test_split.txt, parts/
└── dataset/
    ├── train_crop/   bbox-cropped, used for training
    ├── train/        uncropped, used for pretraining and prototype projection
    ├── test_crop/    bbox-cropped, used for test accuracy
    └── test_full/    uncropped, used for test-set prototype projection
```

Run with `--data_dir /path/to/CUB_200_2011/dataset --cub_layout pipnet`.

### Which to use

`imagefolder` is what you can run today, and it is the honest apples-to-apples setting
against INTR/PromptCAM, which also train on uncropped images. `pipnet` reproduces the
paper's numbers (the paper trains on bbox crops) **and** is the only layout that enables
the prototype part-purity evaluation, which needs `parts/part_locs.txt`, `parts/parts.txt`
and `images.txt`. Under `imagefolder` that stage is skipped with a printed warning
rather than crashing — accuracy and all prototype visualisations still run.

---

## 4. Running

```bash
bash run_cub_dino.sh                                  # ViT-B/16 @224, 10 pretrain + 60 epochs
DATA_DIR=/home/paul/Paul/DATASETS/CUB GPU=0 bash run_cub_dino.sh
PRESET=lowmem bash run_cub_dino.sh                    # if you hit CUDA OOM
PRESET=hires  bash run_cub_dino.sh                    # 448px -> 28x28 prototype grid
```

The equivalent raw command:

```bash
python3 main.py \
  --dataset CUB-200-2011 \
  --data_dir /home/paul/Paul/DATASETS/CUB \
  --cub_layout imagefolder \
  --net dino_vitb16 \
  --image_size 224 \
  --batch_size 48 --batch_size_pretrain 64 \
  --epochs 60 --epochs_pretrain 10 --freeze_epochs 10 \
  --lr 0.05 --lr_block 0.0001 --lr_net 0.0001 \
  --gpu_ids 0 --num_workers 8 \
  --log_dir ./runs/pipnet_cub_dino_vitb16 \
  --disable_ood_eval
```

Long runs: `nohup bash run_cub_dino.sh > nohup.log 2>&1 &`, then watch
`tail -f runs/<name>/tqdm.txt`.

Evaluate / visualise a finished checkpoint without retraining:

```bash
PRESET=eval STATE_DICT=./runs/pipnet_cub_dino_vitb16/checkpoints/net_trained \
  bash run_cub_dino.sh
```

---

## 5. Why the extra 1×1 conv

PIP-Net's add-on layer is a softmax **over the channel dimension**: at each spatial
location the channels are read as a distribution over prototypes. A CNN trunk ends in
activations that are non-negative and already peaky, so upstream softmaxes them directly
(`--num_features 0`, no extra layer).

A ViT ends in a `LayerNorm`, and DINO ViT-B/16 carries a few **massive-activation outlier
channels**: measured on the real pretrained features, channel 272 averages `|32|` and
channel 186 averages `|16|`, where the median channel averages `|1.2|`. Softmaxing those
768 channels directly saturates on the outlier dims. Measured over a batch:

| add-on | max pooled score | prototypes scoring > 0.1 (of 768) | argmax on an outlier channel |
|---|---|---|---|
| raw token softmax | 1.000 | **2** | **100% of locations** |
| learnable 1×1 conv | 0.463 | 48 | — |

So without it, the same one or two prototypes fire at every patch of every image, leaving
roughly 2 usable prototypes for 200 classes. This is a property of the ViT feature space,
not something the align/tanh losses recover from.

For ViT backbones `get_network` therefore inserts a learnable `1×1 conv (768 → 768)`
before the softmax, which decorrelates the outliers away. It is trained at `lr_block × 10`
alongside the rest of the add-on layer, exactly as upstream trains its `--num_features`
conv, and the prototype count is unchanged at 768. Pass `--disable_vit_add_on_conv` to
reproduce the degenerate version.

Reproduce the outlier measurement yourself:

```bash
python3 - <<'PY'
import torch, timm
m = timm.create_model('vit_base_patch16_224.dino', pretrained=True, num_classes=0).eval()
with torch.no_grad():
    t = m.forward_features(torch.randn(4,3,224,224))[:, 1:]   # patch tokens, post-LayerNorm
per_ch = t.reshape(-1, t.shape[-1]).abs().mean(0)
top = per_ch.topk(5)
print('outlier channels :', [(i.item(), round(v.item(),1)) for v,i in zip(*top)])
print('median channel   :', round(per_ch.median().item(), 2))
sm = t.softmax(-1)
print('prototypes >0.1 per location :', (sm>0.1).float().sum(-1).mean().item())
print('argmax on an outlier channel :', torch.isin(sm.argmax(-1), top.indices).float().mean().item())
PY
```

---

## 6. Hyperparameters and memory

`--lr` (0.05, prototype→class layer) is left at the paper's value. The backbone rates
`--lr_block` / `--lr_net` are dropped from the paper's `5e-4` to `1e-4`, because a ViT
finetunes at a smaller step size than a ConvNeXt. If prototypes collapse (align loss
stalls, `num_scores>0.1` in `tqdm.txt` stays near zero) try lowering to `5e-5`; if the
model underfits, raise toward `3e-4`.

Note each training step pushes **two augmented views**, so the batch reaching the ViT is
`2 × --batch_size`. That is the main memory driver.

Epoch count follows the paper's rule of thumb — around 10,000 optimiser steps in stage 2,
2,000 in pretraining. CUB has 5,994 training images, so at `--batch_size 48` that is
124 steps/epoch, and 60 epochs ≈ 7.4k steps. Push `--epochs` to 80–90 if you want to hit
the rule exactly; check the real step count in `tqdm.txt`.

**On CUDA OOM**, in the order worth trying:

1. `--dino_grad_checkpointing` — recomputes ViT block activations in the backward pass.
   Roughly halves activation memory for ~30% slower steps. Cheapest win.
2. `--dino_freeze_early` — keeps `patch_embed`, the position embedding and the lower
   blocks frozen for the whole run instead of unfreezing them at `--freeze_epochs`.
3. Lower `--batch_size` / `--batch_size_pretrain`.
4. `--dino_blocks_freeze 1` — trains fewer blocks at `--lr_block`.
5. `--net dino_vits16` — ViT-S/16, 384 channels, about a quarter of the compute.

`PRESET=lowmem` applies 1–3 together.

---

## 7. Reading the results

In `--log_dir`:

- `log_epoch_overview.csv` — per epoch: top-1, top-5, number of non-zero prototypes,
  mean train accuracy, loss. This is your main results table.
- `out.txt` — full stdout, ending with the learned scoring sheet
  (`Class c ( name ): has N relevant prototypes: [(id, weight), ...]`).
- `tqdm.txt` — per-iteration losses. `LA` align, `LT` tanh, `LC` classification,
  `num_scores>0.1` is how many prototypes actually fire — the number to watch during
  pretraining. If it stays at 0, the prototypes are not sharpening.
- `checkpoints/net_pretrained`, `net_trained`, `net_trained_last`.
- `visualised_pretrained_prototypes_topk/grid_topk_all.png` — prototypes after stage 1.
- `visualised_prototypes_topk/grid_topk_all.png` — final prototypes, one row each.
- `visualised_prototypes/` — every patch matching each prototype, plus source images with
  the location boxed in yellow.
- `visualization_results/` — per-test-image local explanations.

The prototype-visualisation stages after training are slower than they look: upstream's
`visualize_topk` re-runs a **batch-1 forward pass per (prototype, top-k image) pair**, so
768 prototypes × 10 is up to ~7,700 forwards, and it runs twice (after pretraining and
after training). Budget an extra 10–20 minutes on GPU at the end of the job. Training
itself is the same order as any ViT-B finetune on CUB.

---

## 8. Things to know before you compare numbers

- **Grid granularity.** The paper's `convnext_tiny_26` produces a 26×26 latent grid;
  ViT-B/16 at 224px gives 14×14. Fewer, larger prototype locations means coarser
  localisation. `PRESET=hires` (448px → 28×28) or `--net dino_vitb8` (28×28 at 224px)
  restore the granularity at higher cost. Worth running at least one hires job before
  concluding anything about localisation quality.
- **Visualisation patch size.** Boxes are drawn 32px wide by default, inherited from the
  26×26 setup. At a 14×14 grid the stride between locations is 15px, so boxes overlap
  more than upstream. `--patch_size_vis` adjusts this; it is cosmetic and does not touch
  the model.
- **Uncropped vs cropped.** Under `--cub_layout imagefolder` there are no bounding-box
  crops, so expect lower absolute accuracy than the paper's CUB number.
- **Part-purity numbers** are only produced under `--cub_layout pipnet`.
- The self-supervised DINO features were never trained with labels, which is the point —
  but it also means the first epochs look worse than an ImageNet-supervised backbone
  before the align loss organises the prototypes.
