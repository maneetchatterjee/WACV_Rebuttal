import argparse
import os
import sys

OK, BAD = "  [ok] ", "  [!!] "
failures = []


def check(label, fn):
    try:
        detail = fn()
        print(OK + label + (": " + detail if detail else ""))
    except Exception as e:
        print(BAD + label + ": " + str(e))
        failures.append(label)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data_dir', type=str, default='/home/paul/Paul/DATASETS/CUB')
    p.add_argument('--cub_layout', type=str, default='imagefolder', choices=['imagefolder', 'pipnet'])
    p.add_argument('--net', type=str, default='dino_vitb16')
    p.add_argument('--image_size', type=int, default=224)
    p.add_argument('--skip_weights', action='store_true', help='Do not download the DINO weights.')
    args = p.parse_args()

    print("\n== packages ==")

    def _torch():
        import torch
        return torch.__version__
    check("torch", _torch)

    def _timm():
        import timm
        v = tuple(int(x) for x in timm.__version__.split('.')[:2])
        if v < (0, 9):
            raise RuntimeError(f"timm {timm.__version__} is too old, need >= 0.9.8")
        return timm.__version__
    check("timm", _timm)

    for mod in ('torchvision', 'sklearn', 'tqdm', 'matplotlib', 'pandas'):
        check(mod, lambda m=mod: __import__(m).__version__ if hasattr(__import__(m), '__version__') else '')

    print("\n== gpu ==")

    def _gpu():
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("no CUDA device visible; training on CPU is not practical")
        names = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
        free, total = torch.cuda.mem_get_info(0)
        return f"{len(names)} device(s): {names}, {free/2**30:.1f}/{total/2**30:.1f} GiB free on cuda:0"
    check("cuda", _gpu)

    print("\n== data ==")

    def _data():
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from util.data import get_cub_dirs
        dirs = get_cub_dirs(args)
        labels = ('train', 'project', 'test', 'pretrain', 'test-projection')
        lines = []
        for label, d in zip(labels, dirs):
            if not os.path.isdir(d):
                raise FileNotFoundError(f"{label} directory missing: {d}")
            classes = sorted(e for e in os.listdir(d) if os.path.isdir(os.path.join(d, e)))
            n_img = sum(len(fs) for _, _, fs in os.walk(d))
            lines.append(f"\n      {label:16s} {len(classes):4d} classes, {n_img:6d} images  {d}")
        return "".join(lines)
    check("CUB layout '%s'" % args.cub_layout, _data)

    print("\n== backbone ==")

    def _weights():
        if args.skip_weights:
            return "skipped (--skip_weights)"
        from pipnet.pipnet import base_architecture_to_features
        from features.dino_features import is_dino_net
        if not is_dino_net(args.net):
            return f"{args.net} is not a DINO backbone, nothing to fetch"
        feats = base_architecture_to_features[args.net](pretrained=True, img_size=args.image_size)
        grid = args.image_size // feats.patch_size
        if args.image_size % feats.patch_size:
            raise ValueError(
                f"--image_size {args.image_size} is not a multiple of the patch size "
                f"{feats.patch_size}; the token grid would not be square")
        return f"{args.net} loaded, {feats.out_channels} channels, {grid}x{grid} prototype grid"
    check("DINO weights", _weights)

    print()
    if failures:
        print(f"{len(failures)} check(s) failed: {failures}")
        sys.exit(1)
    print("All checks passed. Launch with:  bash run_cub_dino.sh")


if __name__ == '__main__':
    main()
