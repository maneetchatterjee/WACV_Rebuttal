import math

import torch
import torch.nn as nn

try:
    import timm
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The DINO backbones need timm. Install it with `pip install timm>=0.9.8`."
    ) from exc


class DINOViTFeatures(nn.Module):
    """Wraps a timm ViT so that it behaves like PIP-Net's CNN feature extractors."""

    def __init__(self,
                 model_name: str,
                 pretrained: bool = True,
                 img_size: int = 224,
                 drop_path_rate: float = 0.0,
                 grad_checkpointing: bool = False,
                 ckpt_path: str = ''):
        super().__init__()

        create_kwargs = dict(
            pretrained=pretrained,
            num_classes=0,       # drop the classification head, we only want tokens
            img_size=img_size,
            drop_path_rate=drop_path_rate,
        )
        try:
            # Lets the position embedding be resampled on the fly, so --image_size
            # other than the checkpoint's native size just works.
            self.vit = timm.create_model(model_name, dynamic_img_size=True, **create_kwargs)
        except TypeError:
            # timm < 0.9.6 has no dynamic_img_size; img_size= still resamples pos_embed
            # at construction time, it is only variable input sizes that stop working.
            print("timm without dynamic_img_size support, falling back to a fixed input size.",
                  flush=True)
            self.vit = timm.create_model(model_name, **create_kwargs)

        if ckpt_path:
            state = torch.load(ckpt_path, map_location='cpu')
            for key in ('model', 'state_dict', 'teacher', 'student'):
                if isinstance(state, dict) and key in state:
                    state = state[key]
                    break
            state = {k.replace('module.', '').replace('backbone.', ''): v for k, v in state.items()}
            missing, unexpected = self.vit.load_state_dict(state, strict=False)
            print(f"Loaded DINO weights from {ckpt_path}. "
                  f"Missing: {len(missing)}, unexpected: {len(unexpected)}", flush=True)

        if grad_checkpointing:
            self.vit.set_grad_checkpointing(True)
            print("Gradient checkpointing enabled on the ViT backbone.", flush=True)

        self.model_name = model_name
        self.out_channels = self.vit.embed_dim
        self.patch_size = self.vit.patch_embed.patch_size[0]
        self.num_prefix_tokens = getattr(self.vit, 'num_prefix_tokens', 1)
        self.depth = len(self.vit.blocks)

        print(f"DINO backbone {model_name}: {self.depth} blocks, {self.out_channels} channels, "
              f"patch {self.patch_size}, expected grid "
              f"{img_size // self.patch_size}x{img_size // self.patch_size} at {img_size}px",
              flush=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = self.vit.forward_features(x)          # (B, num_prefix + H*W, C)
        tokens = tokens[:, self.num_prefix_tokens:]    # drop CLS (+ register) tokens

        b, n, c = tokens.shape
        h = int(round(math.sqrt(n)))
        if h * h != n:
            raise ValueError(
                f"Expected a square token grid but got {n} patch tokens. "
                "PIP-Net's visualisation assumes square inputs, so keep --image_size square "
                "and divisible by the ViT patch size."
            )
        # timm lays patch tokens out row-major, so this restores the (H, W) grid.
        return tokens.transpose(1, 2).reshape(b, c, h, h)


def _make(model_name):
    def _factory(pretrained: bool = True, **kwargs):
        return DINOViTFeatures(model_name, pretrained=pretrained, **kwargs)
    return _factory


# DINO v1 (Caron et al., ICCV 2021) - self-supervised ViTs, the ones PromptCAM/INTR use.
dino_vitb16_features = _make('vit_base_patch16_224.dino')
dino_vits16_features = _make('vit_small_patch16_224.dino')
dino_vitb8_features = _make('vit_base_patch8_224.dino')

# DINOv2 (Oquab et al., 2023) - patch 14, stronger dense features.
dinov2_vitb14_features = _make('vit_base_patch14_dinov2.lvd142m')
dinov2_vits14_features = _make('vit_small_patch14_dinov2.lvd142m')
dinov2_vitb14_reg_features = _make('vit_base_patch14_reg4_dinov2.lvd142m')


#: Backbone names in this file. Used elsewhere to branch on "is this a ViT?".
DINO_NETS = (
    'dino_vitb16',
    'dino_vits16',
    'dino_vitb8',
    'dinov2_vitb14',
    'dinov2_vits14',
    'dinov2_vitb14_reg',
)


def is_dino_net(net_name: str) -> bool:
    return net_name in DINO_NETS
