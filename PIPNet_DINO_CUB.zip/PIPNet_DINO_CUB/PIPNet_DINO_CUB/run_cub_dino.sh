#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PIP-Net with a DINO ViT backbone on CUB-200-2011.
#
#   bash run_cub_dino.sh                 # train (default preset)
#   PRESET=lowmem bash run_cub_dino.sh   # same, but fits a smaller GPU
#   PRESET=hires  bash run_cub_dino.sh   # 448px input -> 28x28 prototype grid
#   PRESET=eval   bash run_cub_dino.sh   # no training, just visualise a checkpoint
#
# Override anything from the command line, e.g.
#   DATA_DIR=/scratch/CUB GPU=1 EPOCHS=90 bash run_cub_dino.sh
# ---------------------------------------------------------------------------
set -euo pipefail

# ----------------------------------------------------------------- edit these
DATA_DIR="${DATA_DIR:-/home/paul/Paul/DATASETS/CUB}"   # folder holding train/ and val/
CUB_LAYOUT="${CUB_LAYOUT:-imagefolder}"                # imagefolder | pipnet
GPU="${GPU:-0}"
NUM_WORKERS="${NUM_WORKERS:-8}"
PRESET="${PRESET:-default}"

NET="${NET:-dino_vitb16}"          # dino_vits16 | dino_vitb16 | dinov2_vitb14 | ...
IMAGE_SIZE="${IMAGE_SIZE:-224}"
BATCH_SIZE="${BATCH_SIZE:-48}"
BATCH_SIZE_PRETRAIN="${BATCH_SIZE_PRETRAIN:-64}"
EPOCHS="${EPOCHS:-60}"
EPOCHS_PRETRAIN="${EPOCHS_PRETRAIN:-10}"
FREEZE_EPOCHS="${FREEZE_EPOCHS:-10}"

# Classifier lr is PIP-Net's own; the backbone lrs are lowered from the paper's 5e-4
# because a ViT finetunes at a smaller step size than a ConvNeXt.
LR="${LR:-0.05}"
LR_BLOCK="${LR_BLOCK:-0.0001}"
LR_NET="${LR_NET:-0.0001}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.0}"

EXTRA_ARGS="${EXTRA_ARGS:-}"
STATE_DICT="${STATE_DICT:-}"
# -----------------------------------------------------------------------------

case "$PRESET" in
  default) ;;
  lowmem)
    # Recompute ViT activations in the backward pass and never unfreeze the lower
    # blocks. Roughly a third of the memory, ~30% slower per step.
    BATCH_SIZE="${BATCH_SIZE_OVERRIDE:-24}"
    BATCH_SIZE_PRETRAIN="${BATCH_SIZE_PRETRAIN_OVERRIDE:-32}"
    EXTRA_ARGS="$EXTRA_ARGS --dino_grad_checkpointing --dino_freeze_early"
    ;;
  hires)
    # 448px -> 28x28 latent grid, matching the 26x26 granularity of the paper's
    # convnext_tiny_26 backbone. ~4x the attention cost.
    IMAGE_SIZE=448
    BATCH_SIZE=16
    BATCH_SIZE_PRETRAIN=24
    EXTRA_ARGS="$EXTRA_ARGS --dino_grad_checkpointing --patch_size_vis 32"
    ;;
  eval)
    # Load a trained checkpoint and only run evaluation + prototype visualisation.
    EPOCHS=0
    EPOCHS_PRETRAIN=0
    : "${STATE_DICT:?PRESET=eval needs STATE_DICT=/path/to/checkpoints/net_trained}"
    ;;
  *)
    echo "Unknown PRESET '$PRESET' (expected default|lowmem|hires|eval)" >&2
    exit 1
    ;;
esac

RUN_NAME="${RUN_NAME:-pipnet_cub_${NET}_${IMAGE_SIZE}}"
LOG_DIR="${LOG_DIR:-./runs/${RUN_NAME}}"
mkdir -p "$LOG_DIR"

if [ -n "$STATE_DICT" ]; then
  EXTRA_ARGS="$EXTRA_ARGS --state_dict_dir_net $STATE_DICT"
fi

echo "=============================================================="
echo " PIP-Net + DINO on CUB-200-2011"
echo "   preset      : $PRESET"
echo "   backbone    : $NET  @ ${IMAGE_SIZE}px"
echo "   data        : $DATA_DIR  (layout: $CUB_LAYOUT)"
echo "   log dir     : $LOG_DIR"
echo "   gpu         : $GPU"
echo "   epochs      : $EPOCHS_PRETRAIN pretrain + $EPOCHS train"
echo "   batch       : $BATCH_SIZE (pretrain $BATCH_SIZE_PRETRAIN)"
echo "   extra       : $EXTRA_ARGS"
echo "=============================================================="

python3 main.py \
  --dataset CUB-200-2011 \
  --data_dir "$DATA_DIR" \
  --cub_layout "$CUB_LAYOUT" \
  --net "$NET" \
  --image_size "$IMAGE_SIZE" \
  --batch_size "$BATCH_SIZE" \
  --batch_size_pretrain "$BATCH_SIZE_PRETRAIN" \
  --epochs "$EPOCHS" \
  --epochs_pretrain "$EPOCHS_PRETRAIN" \
  --freeze_epochs "$FREEZE_EPOCHS" \
  --optimizer Adam \
  --lr "$LR" \
  --lr_block "$LR_BLOCK" \
  --lr_net "$LR_NET" \
  --weight_decay "$WEIGHT_DECAY" \
  --num_features 0 \
  --seed 1 \
  --gpu_ids "$GPU" \
  --num_workers "$NUM_WORKERS" \
  --log_dir "$LOG_DIR" \
  --dir_for_saving_images visualization_results \
  --extra_test_image_folder '' \
  --disable_ood_eval \
  $EXTRA_ARGS

echo "Finished. Results in $LOG_DIR"
echo "  accuracy per epoch : $LOG_DIR/log_epoch_overview.csv"
echo "  full stdout        : $LOG_DIR/out.txt"
echo "  per-iteration log  : $LOG_DIR/tqdm.txt"
echo "  prototypes         : $LOG_DIR/visualised_prototypes_topk/grid_topk_all.png"
