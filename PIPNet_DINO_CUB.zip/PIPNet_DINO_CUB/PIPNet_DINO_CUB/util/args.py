import os
import argparse
import pickle
import numpy as np
import random
import re
import torch
import torch.optim

from features.dino_features import is_dino_net

"""
    Utility functions for handling parsed arguments

"""

_BLOCK_RE = re.compile(r'(?:^|\.)blocks\.(\d+)\.')


def _vit_block_index(param_name: str):
    """Return the transformer block index a parameter belongs to, or None for the stem/head."""
    match = _BLOCK_RE.search(param_name)
    return int(match.group(1)) if match else None


def get_args() -> argparse.Namespace:

    parser = argparse.ArgumentParser('Train a PIP-Net')
    parser.add_argument('--dataset',
                        type=str,
                        default='CUB-200-2011',
                        help='Data set on PIP-Net should be trained')
    parser.add_argument('--validation_size',
                        type=float,
                        default=0.,
                        help='Split between training and validation set. Can be zero when there is a separate test or validation directory. Should be between 0 and 1. Used for partimagenet (e.g. 0.2)')
    parser.add_argument('--net',
                        type=str,
                        default='convnext_tiny_26',
                        help='Base network used as backbone of PIP-Net. Default is convnext_tiny_26 with adapted strides to output 26x26 latent representations. Other option is convnext_tiny_13 that outputs 13x13 (smaller and faster to train, less fine-grained). Pretrained network on iNaturalist is only available for resnet50_inat. Options are: resnet18, resnet34, resnet50, resnet50_inat, resnet101, resnet152, convnext_tiny_26, convnext_tiny_13, and the self-supervised ViTs dino_vitb16, dino_vits16, dino_vitb8, dinov2_vitb14, dinov2_vits14, dinov2_vitb14_reg.')
    parser.add_argument('--batch_size',
                        type=int,
                        default=64,
                        help='Batch size when training the model using minibatch gradient descent. Batch size is multiplied with number of available GPUs')
    parser.add_argument('--batch_size_pretrain',
                        type=int,
                        default=128,
                        help='Batch size when pretraining the prototypes (first training stage)')
    parser.add_argument('--epochs',
                        type=int,
                        default=60,
                        help='The number of epochs PIP-Net should be trained (second training stage)')
    parser.add_argument('--epochs_pretrain',
                        type=int,
                        default = 10,
                        help='Number of epochs to pre-train the prototypes (first training stage). Recommended to train at least until the align loss < 1'
                        )
    parser.add_argument('--optimizer',
                        type=str,
                        default='Adam',
                        help='The optimizer that should be used when training PIP-Net')
    parser.add_argument('--lr',
                        type=float,
                        default=0.05, 
                        help='The optimizer learning rate for training the weights from prototypes to classes')
    parser.add_argument('--lr_block',
                        type=float,
                        default=0.0005, 
                        help='The optimizer learning rate for training the last conv layers of the backbone')
    parser.add_argument('--lr_net',
                        type=float,
                        default=0.0005, 
                        help='The optimizer learning rate for the backbone. Usually similar as lr_block.') 
    parser.add_argument('--weight_decay',
                        type=float,
                        default=0.0,
                        help='Weight decay used in the optimizer')
    parser.add_argument('--disable_cuda',
                        action='store_true',
                        help='Flag that disables GPU usage if set')
    parser.add_argument('--log_dir',
                        type=str,
                        default='./runs/run_pipnet',
                        help='The directory in which train progress should be logged')
    parser.add_argument('--num_features',
                        type=int,
                        default = 0,
                        help='Number of prototypes. When zero (default) the number of prototypes is the number of output channels of backbone. If this value is set, then a 1x1 conv layer will be added. Recommended to keep 0, but can be increased when number of classes > num output channels in backbone.')
    parser.add_argument('--image_size',
                        type=int,
                        default=224,
                        help='Input images will be resized to --image_size x --image_size (square). Code only tested with 224x224, so no guarantees that it works for different sizes.')
    parser.add_argument('--state_dict_dir_net',
                        type=str,
                        default='',
                        help='The directory containing a state dict with a pretrained PIP-Net. E.g., ./runs/run_pipnet/checkpoints/net_pretrained')
    parser.add_argument('--freeze_epochs',
                        type=int,
                        default = 10,
                        help='Number of epochs where pretrained features_net will be frozen while training classification layer (and last layer(s) of backbone)'
                        )
    parser.add_argument('--dir_for_saving_images',
                        type=str,
                        default='visualization_results',
                        help='Directoy for saving the prototypes and explanations')
    parser.add_argument('--disable_pretrained',
                        action='store_true',
                        help='When set, the backbone network is initialized with random weights instead of being pretrained on another dataset).'
                        )
    parser.add_argument('--weighted_loss',
                        action='store_true',
                        help='Flag that weights the loss based on the class balance of the dataset. Recommended to use when data is imbalanced. ')
    parser.add_argument('--seed',
                        type=int,
                        default=1,
                        help='Random seed. Note that there will still be differences between runs due to nondeterminism. See https://pytorch.org/docs/stable/notes/randomness.html')
    parser.add_argument('--gpu_ids',
                        type=str,
                        default='',
                        help='ID of gpu. Can be separated with comma')
    parser.add_argument('--num_workers',
                        type=int,
                        default=8,
                        help='Num workers in dataloaders.')
    parser.add_argument('--bias',
                        action='store_true',
                        help='Flag that indicates whether to include a trainable bias in the linear classification layer.'
                        )
    parser.add_argument('--extra_test_image_folder',
                        type=str,
                        default='./experiments',
                        help='Folder with images that PIP-Net will predict and explain, that are not in the training or test set. E.g. images with 2 objects or OOD image. Images should be in subfolder. E.g. images in ./experiments/images/, and argument --./experiments')

    # ------------------------------------------------------------------ data layout
    parser.add_argument('--data_dir',
                        type=str,
                        default='',
                        help='Root directory of the dataset. Overrides the hardcoded ./data/... paths, so the same code runs on a server without symlinks. For CUB this is the folder that directly contains the image split folders.')
    parser.add_argument('--cub_layout',
                        type=str,
                        default='pipnet',
                        choices=['pipnet', 'imagefolder'],
                        help="Directory layout of the CUB data. 'pipnet' expects the four folders produced by util/preprocess_cub.py (train_crop, train, test_crop, test_full) and enables the part-purity evaluation. 'imagefolder' expects a plain train/ + val/ (or test/) pair of ImageFolders, uncropped, and skips the part-purity evaluation.")

    # ------------------------------------------------------------------ DINO backbone
    parser.add_argument('--dino_drop_path',
                        type=float,
                        default=0.0,
                        help='Stochastic depth rate for the ViT backbone. 0.0 disables it; 0.1 is a common value when finetuning ViT-B.')
    parser.add_argument('--dino_grad_checkpointing',
                        action='store_true',
                        help='Recompute ViT block activations during the backward pass. Cuts activation memory roughly in half at ~30 percent slower steps. Use this before shrinking the batch size when you hit CUDA OOM.')
    parser.add_argument('--dino_ckpt',
                        type=str,
                        default='',
                        help='Optional path to a local DINO checkpoint. Leave empty to let timm download the pretrained weights from the HuggingFace hub.')
    parser.add_argument('--dino_blocks_train',
                        type=int,
                        default=1,
                        help='Number of final transformer blocks trained at --lr_block from the very first epoch (plus the final LayerNorm). Analogous to layer4.2 for the resnet50 backbone.')
    parser.add_argument('--dino_blocks_freeze',
                        type=int,
                        default=3,
                        help='Number of transformer blocks below those, also trained at --lr_block but held frozen for the first --freeze_epochs epochs.')
    parser.add_argument('--dino_freeze_early',
                        action='store_true',
                        help='Permanently freeze patch_embed, the position embedding and every block below the --dino_blocks_train/--dino_blocks_freeze window, instead of unfreezing them at --lr_net after --freeze_epochs. Large memory saving, mirrors what the resnet50 branch does.')
    parser.add_argument('--disable_vit_add_on_conv',
                        action='store_true',
                        help="Softmax the raw ViT tokens instead of inserting a learnable 1x1 conv before the prototype softmax. Only useful as an ablation: DINO's massive-activation outlier channels make the raw softmax saturate, leaving about 2 usable prototypes out of 768.")
    parser.add_argument('--patch_size_vis',
                        type=int,
                        default=0,
                        help='Side length in pixels of the image patch drawn for each latent location during visualisation. 0 keeps the upstream default of 32.')

    # ------------------------------------------------------------------ run control
    parser.add_argument('--disable_ood_eval',
                        action='store_true',
                        help='Skip the out-of-distribution evaluation at the end of training. That step needs the CARS and PETS datasets to be present; without them it is skipped with a warning anyway.')
    parser.add_argument('--disable_cub_parts_eval',
                        action='store_true',
                        help='Skip the CUB prototype part-purity evaluation. It needs parts/part_locs.txt, parts/parts.txt and images.txt from the raw CUB-200-2011 release; without them it is skipped with a warning anyway.')
    parser.add_argument('--no_redirect_output',
                        action='store_true',
                        help='Keep printing to the console instead of redirecting stdout/stderr into --log_dir/out.txt and tqdm.txt. Useful when the job scheduler already captures output.')

    args = parser.parse_args()
    if len(args.log_dir.split('/'))>2:
        if not os.path.exists(args.log_dir):
            os.makedirs(args.log_dir)


    return args


def save_args(args: argparse.Namespace, directory_path: str) -> None:
    """
    Save the arguments in the specified directory as
        - a text file called 'args.txt'
        - a pickle file called 'args.pickle'
    :param args: The arguments to be saved
    :param directory_path: The path to the directory where the arguments should be saved
    """
    # If the specified directory does not exists, create it
    if not os.path.isdir(directory_path):
        os.mkdir(directory_path)
    # Save the args in a text file
    with open(directory_path + '/args.txt', 'w') as f:
        for arg in vars(args):
            val = getattr(args, arg)
            if isinstance(val, str):  # Add quotation marks to indicate that the argument is of string type
                val = f"'{val}'"
            f.write('{}: {}\n'.format(arg, val))
    # Pickle the args for possible reuse
    with open(directory_path + '/args.pickle', 'wb') as f:
        pickle.dump(args, f)                                                                               
    
def get_optimizer_nn(net, args: argparse.Namespace) -> torch.optim.Optimizer:
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)

    #create parameter groups
    params_to_freeze = []
    params_to_train = []
    params_backbone = []
    # set up optimizer
    if 'resnet50' in args.net: 
        # freeze resnet50 except last convolutional layer
        for name,param in net.module._net.named_parameters():
            if 'layer4.2' in name:
                params_to_train.append(param)
            elif 'layer4' in name or 'layer3' in name:
                params_to_freeze.append(param)
            elif 'layer2' in name:
                params_backbone.append(param)
            else: #such that model training fits on one gpu. 
                param.requires_grad = False
                # params_backbone.append(param)
    
    elif 'convnext' in args.net:
        print("chosen network is convnext", flush=True)
        for name,param in net.module._net.named_parameters():
            if 'features.7.2' in name: 
                params_to_train.append(param)
            elif 'features.7' in name or 'features.6' in name:
                params_to_freeze.append(param)
            # CUDA MEMORY ISSUES? COMMENT LINE 202-203 AND USE THE FOLLOWING LINES INSTEAD
            # elif 'features.5' in name or 'features.4' in name:
            #     params_backbone.append(param)
            # else:
            #     param.requires_grad = False
            else:
                params_backbone.append(param)

    elif is_dino_net(args.net):
        # Same three-tier split as the CNN backbones, expressed over transformer blocks:
        #   params_to_train   the top --dino_blocks_train blocks + the final LayerNorm,
        #                     trained at --lr_block from epoch 1
        #   params_to_freeze  the --dino_blocks_freeze blocks below those, same lr but
        #                     held frozen until --freeze_epochs
        #   params_backbone   patch_embed / pos_embed / cls_token / remaining blocks,
        #                     trained at --lr_net once the backbone unfreezes
        depth = net.module._net.depth
        n_train = max(0, min(args.dino_blocks_train, depth))
        n_freeze = max(0, min(args.dino_blocks_freeze, depth - n_train))
        train_ids = set(range(depth - n_train, depth))
        freeze_ids = set(range(depth - n_train - n_freeze, depth - n_train))
        print(f"chosen network is {args.net}: training blocks {sorted(train_ids)} at lr_block, "
              f"blocks {sorted(freeze_ids)} at lr_block after freeze_epochs, "
              f"rest {'frozen permanently' if args.dino_freeze_early else 'at lr_net'}", flush=True)

        for name, param in net.module._net.named_parameters():
            block_id = _vit_block_index(name)
            if block_id is not None and block_id in train_ids:
                params_to_train.append(param)
            elif block_id is not None and block_id in freeze_ids:
                params_to_freeze.append(param)
            elif name in ('vit.norm.weight', 'vit.norm.bias'):
                # The trunk-final LayerNorm sits directly on top of the last block, so it
                # belongs with the layers we always train. Matched exactly so that e.g.
                # vit.patch_embed.norm does not get swept in.
                params_to_train.append(param)
            elif args.dino_freeze_early:
                param.requires_grad = False
            else:
                params_backbone.append(param)
    else:
        print("Network is not ResNet, ConvNext or DINO ViT.", flush=True)
    classification_weight = []
    classification_bias = []
    for name, param in net.module._classification.named_parameters():
        if 'weight' in name:
            classification_weight.append(param)
        elif 'multiplier' in name:
            param.requires_grad = False
        else:
            if args.bias:
                classification_bias.append(param)
    
    paramlist_net = [
            {"params": params_backbone, "lr": args.lr_net, "weight_decay_rate": args.weight_decay},
            {"params": params_to_freeze, "lr": args.lr_block, "weight_decay_rate": args.weight_decay},
            {"params": params_to_train, "lr": args.lr_block, "weight_decay_rate": args.weight_decay},
            {"params": net.module._add_on.parameters(), "lr": args.lr_block*10., "weight_decay_rate": args.weight_decay}]
            
    paramlist_classifier = [
            {"params": classification_weight, "lr": args.lr, "weight_decay_rate": args.weight_decay},
            {"params": classification_bias, "lr": args.lr, "weight_decay_rate": 0},
    ]
          
    if args.optimizer == 'Adam':
        optimizer_net = torch.optim.AdamW(paramlist_net,lr=args.lr,weight_decay=args.weight_decay)
        optimizer_classifier = torch.optim.AdamW(paramlist_classifier,lr=args.lr,weight_decay=args.weight_decay)
        return optimizer_net, optimizer_classifier, params_to_freeze, params_to_train, params_backbone
    else:
        raise ValueError("this optimizer type is not implemented")

