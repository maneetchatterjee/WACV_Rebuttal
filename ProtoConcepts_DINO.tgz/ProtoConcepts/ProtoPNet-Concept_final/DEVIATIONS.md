# Deviations from upstream ProtoConcepts

For the methods / reproducibility section. **These runs are not "the default repository with
a DINO backbone".** Below is every difference, split into changes that were forced and
changes that were judgement calls.

Upstream reference: `settings_original.py.bak` (the unmodified `settings.py`), whose values
are tuned for `resnet152` on **bounding-box-cropped, offline-augmented CUB-200-2011**.

---

## A. Unchanged

The model and its objective are untouched:

| | value |
|---|---|
| `add_on_layers_type` | `regular` (Conv 1x1 -> ReLU -> Conv 1x1 -> Sigmoid) |
| `last_layer_type` | `single` |
| `use_cap`, `ctrl`, `ltwo` | True, True, True |
| `prototype_activation_function` | `log` |
| prototype depth | 128 |
| `clst_k` | 10 |
| `cap_width` | 6.0 (except the GBCU retry, below) |
| all loss coefficients | `crs_ent 1, clst 0.8, sep -0.08, l1 1e-4, relu 1e-3, dist 1.0, cap 0.01` |
| `num_finetune_epochs` | 20 |
| add-on / prototype / last-layer learning rates | 3e-3, 3e-3, 1e-4 |

No loss term, no architectural component, and no prototype mechanism was modified. `push` is
disabled, which is upstream's own default when `use_cap=True`.

---

## B. Forced changes (no alternative existed)

**1. Backbone.** `resnet152` -> `dino_vitb16`. The intended change.

**2. Prototype count.** `PPNet` asserts `num_prototypes % num_classes == 0`, so upstream's
fixed 2000 is only valid for 200 classes. We use `10 x num_classes`, preserving upstream's
10-per-class ratio:

| dataset | classes | prototypes | same ratio as upstream? |
|---|---|---|---|
| CUB | 200 | 2000 | yes, and numerically identical |
| Cars | 196 | 1960 | yes (upstream ships this as a commented-out value) |
| Flowers | 102 | 1020 | yes |
| AID | 30 | 300 | yes |
| GBCU | 3 | 30, then 60 in the retry | 60 is a deviation, see D |

**3. Data pipeline.** Upstream reads `train_cropped_augmented/`, a directory expanded roughly
**30x offline** with Augmentor, from bbox-cropped images. Our datasets are plain
`train/` + `val/` ImageFolder trees, uncropped, with no offline-augmented variant. So
augmentation happens online (`RandomAffine(15, shear=10)` + flips) instead. This single fact
drives change C1.

**4. `joint_lr_step_size`.** 5 -> 30/50/80. `StepLR(gamma=0.1)` every 5 epochs is calibrated
for a 15-epoch run. Leaving it at 5 across 150 epochs would decay the learning rate by
`0.1^30`, i.e. to zero. Scaled proportionally with the epoch count.

**5. Engineering fixes**, none of which affect the objective: ViT `conv_info()` for
receptive-field maths, channel count read from the wrapper rather than the last `Conv2d`,
device-awareness instead of hardcoded `.cuda()`, atomic and best-only checkpoint saving,
and `target_accu` 0.70 -> 0.0 (upstream silently saved nothing below 70%).

---

## C. Judgement calls (revertible; these are the ones to defend or drop)

**1. Epoch count.** 15 -> 150 (Cars, AID), 250 (Flowers), 400 (GBCU), ~163 (CUB).
Consequence of B3: upstream's 15 epochs over a 30x-augmented directory is ~450 effective
passes over distinct images and ~36k weight updates. Fifteen epochs over an unaugmented
directory is ~1.2k updates. The increase restores a comparable number of updates; it does
not add data.

**2. Warm epochs.** 5 -> 15/25/40, scaled with C1.

**3. Backbone learning rate.** `features` 1e-4 -> **3e-5**. A ViT finetunes at a smaller step
than a ResNet. This is the one change with no forcing argument behind it, only convention.

**4. Batch size.** 50 -> 64 (Cars, Flowers, AID), 96 (CUB), 16 (GBCU). Chosen for GPU
occupancy; GBCU is smaller specifically to buy more updates from 1,133 images. Note this is
safe for ProtoConcepts in a way it is not for PIP-Net: every loss term here is per-sample
then averaged, so batch size does not change the objective.

**5. Per-dataset augmentation flags**, on the grounds that colour and orientation mean
different things per domain:

| dataset | vertical flip | colour jitter | grayscale |
|---|---|---|---|
| CUB, Flowers | no | no | no |
| Cars | no | 0.3 | no |
| AID | yes | no | no |
| GBCU | no | no | yes |

Vertical flips only for aerial imagery (no canonical "up"); colour jitter only for cars
(paint colour varies within a model) and deliberately **not** for flowers, where colour is
the class cue.

**6. GBCU retry only.** `PC_PROTOS_PER_CLASS` 10 -> 20, `cap_width` 6.0 -> 12.0,
`coefs['cap']` 0.01 -> 0.001. Motivated by a specific failure: 0 of 60 prototypes were
visualisable, so masking produced a constant predictor at the majority-class rate.

---

## D. What this means for claims

- **Only CUB retains upstream's exact prototype configuration** (2000 / 200 classes). Even
  there, epochs, backbone lr, lr step, cropping, and augmentation all differ.
- The comparison against PIP-Net **is** apples-to-apples: identical backbone
  (`vit_base_patch16_224.dino`), identical uncropped `train/`+`val/` splits, both with online
  augmentation.
- The comparison against ProtoConcepts' **published** CUB and Cars numbers is **not**
  apples-to-apples, because those use bbox crops and offline augmentation. Do not present
  our numbers as a reproduction.
- If a reviewer asks "what does default ProtoConcepts give with a DINO backbone?", we do not
  currently have that number. See the control run below.

## E. Recommended control run

Cheap and closes the gap. Upstream defaults except the backbone:

```bash
DATASET=cub GPU=0 env PC_ARCH=dino_vitb16 \
  PC_EPOCHS=15 PC_WARM_EPOCHS=5 PC_TRAIN_BATCH=50 PC_TEST_BATCH=80 \
  PC_LR_FEATURES=1e-4 PC_LR_STEP=5 PC_PROTOS_PER_CLASS=10 \
  PC_SAVE_TARGET_ACCU=0.0 PC_RUN_NAME=upstream_defaults \
  nohup bash run_protoconcepts_dino.sh > pc_cub_default.log 2>&1 &
```

Writes to `saved_models/cub/dino_vitb16/upstream_defaults/`, so it does not disturb the
tuned run. About 20 minutes. Reporting both turns an unexplained discrepancy into a stated
ablation: "with the paper's schedule the DINO backbone reaches X; with a schedule matched to
our un-augmented data it reaches Y."
