# ProtoConcepts with a DINO ViT backbone

[This Looks Like Those: Illuminating Prototypical Concepts Using Multiple Visualizations](https://arxiv.org/abs/2310.18589)
(Ma, Zhao, Chen, Rudin — NeurIPS 2023), with the CNN backbone swapped for a self-supervised
**DINO ViT**, and driven by environment variables so it can run five datasets without
editing source between runs.

This is the **ProtoPNet-Concept** variant (`ProtoPNet-Concept_final/`), the paper's primary
model. The repo also ships ProtoPool-Concept and TesNet-Concept, which are untouched.

---

## 1. What changed

| File | Change |
|---|---|
| `dino_features.py` | **New.** `DINOViTFeatures` folds ViT patch tokens back onto their grid to emit `(B, C, H, W)`, and implements **`conv_info()`** — which ProtoPNet needs for receptive-field maths — as a single conv of kernel = stride = patch size. Six backbones registered. |
| `model_ctrl_caps.py` | Registers the DINO backbones; channel count read from `features.out_channels`, because `patch_embed.proj` is a ViT's *first* conv and the upstream "last Conv2d" heuristic would read the wrong layer. Also device-aware instead of hardcoded `.cuda()`. |
| `settings.py` | Every value now reads an environment variable, defaulting to the original. Adds dataset tag, path layout, per-dataset augmentation flags, and epoch/batch/lr overrides. Original preserved as `settings_original.py.bak`. |
| `main_ctrl_caps.py` | Per-dataset checkpoint directory; **online augmentation** (see below); configurable workers, finetune epochs and save threshold; visualisation can be skipped; CPU fallback. |
| `train_and_test_ctrl_caps.py`, `vis_caps.py` | Device-aware, so the pipeline is smoke-testable without a GPU. |
| `run_protoconcepts_dino.sh`, `check_setup.py` | **New.** Launcher and preflight check. |

### Why `conv_info()` matters

ProtoPNet maps a latent position back to image pixels via
`compute_proto_layer_rf_info_v2(layer_filter_sizes, layer_strides, layer_paddings)`, walking
the CNN's stride/padding stack. A ViT has no such stack. ViT-B/16 is exactly equivalent to
one conv with kernel 16, stride 16, padding 0, which yields `rf_info = [14, 16, 16, 8.0]`
at 224px: a 14x14 grid where cell *n* covers pixels `[16n, 16n+16)`. That is the *nominal*
patch. A ViT's true receptive field is the whole image because attention is global, but the
patch is the right unit for prototype localisation.

**Verified:** `dino_vitb16` produces `[14, 16, 16, 8.0]`; `dinov2_vitb14` produces
`[16, 14, 14, 7.0]`.

### One thing that did *not* need changing

Unlike the PIP-Net port, ProtoConcepts needed no extra projection layer. Its
`add_on_layers_type='regular'` is already `Conv2d -> ReLU -> Conv2d -> Sigmoid`, which both
reduces 768 to 128 channels and bounds the output to `[0,1]` before the L2 prototype
distance. That Sigmoid absorbs DINO's massive-activation outlier channels, so the problem
that forced a 1x1 conv into the PIP-Net port does not arise here.

### Backbones

| `PC_ARCH` | timm weights | Channels | Grid @224 |
|---|---|---|---|
| `dino_vitb16` *(default)* | `vit_base_patch16_224.dino` | 768 | 14x14 |
| `dino_vits16` | `vit_small_patch16_224.dino` | 384 | 14x14 |
| `dino_vitb8` | `vit_base_patch8_224.dino` | 768 | 28x28 |
| `dino_vits8` | `vit_small_patch8_224.dino` | 384 | 28x28 |
| `dinov2_vitb14` | `vit_base_patch14_dinov2.lvd142m` | 768 | 16x16 |
| `dinov2_vits14` | `vit_small_patch14_dinov2.lvd142m` | 384 | 16x16 |

`dino_vitb16` matches the INTR++/PromptCAM and PIP-Net runs, so results are comparable.

---

## 2. Setup

```bash
tar xzf ProtoConcepts_DINO.tgz && cd ProtoConcepts_DINO/ProtoPNet-Concept_final
pip install -r requirements.txt      # opencv is mandatory: vis_caps imports cv2
python3 check_setup.py --data_path /home/paul/Paul/DATASETS/CUB --dataset cub
```

---

## 3. Running

```bash
DATASET=cub    GPU=0 nohup bash run_protoconcepts_dino.sh > pc_cub.log 2>&1 &
DATASET=gbcu   GPU=1 nohup bash run_protoconcepts_dino.sh > pc_gbcu.log 2>&1 &
DATASET=aid    GPU=2 nohup bash run_protoconcepts_dino.sh > pc_aid.log 2>&1 &
DATASET=car    GPU=3 nohup bash run_protoconcepts_dino.sh > pc_car.log 2>&1 &
DATASET=flower GPU=0 nohup bash run_protoconcepts_dino.sh > pc_flower.log 2>&1 &
```

- Checkpoints: `saved_models/<dataset>/<arch>/<run>/*.pth` — separate per dataset.
- Training log: `saved_models/<dataset>/<arch>/<run>/train.log`
- Prototype visualisations: `saved_models/<dataset>/<arch>/<run>/img/`

**Class counts are auto-detected** from the number of directories under `train/`. This
matters because ProtoPNet asserts `num_prototypes % num_classes == 0`. The script computes
`num_prototypes = PC_PROTOS_PER_CLASS x num_classes` (default 10 per class, as in the
paper's CUB config): 2000 for CUB, 1960 for Cars, 1020 for Flowers, 300 for AID, 30 for GBCU.

### Per-dataset augmentation

Upstream points `train_dir` at a directory augmented **offline** with Augmentor (~30x more
images). With a plain `train/` folder that augmentation has to happen online instead, or the
model sees far less variation than the paper's recipe. The flags below are class-semantics
decisions, not tuning:

| dataset | vertical flip | colour jitter | grayscale | reason |
|---|---|---|---|---|
| cub | no | no | no | colour is class-defining |
| gbcu | no | no | **yes** | ultrasound is intensity-only |
| aid | **yes** | no | no | aerial imagery has no canonical "up" |
| car | no | **0.3** | no | same model, different paint |
| flower | no | no | no | **colour is the class cue** — jittering it destroys the signal |

Override with `PC_VFLIP`, `PC_COLOR_JITTER`, `PC_GRAY`.

---

## 4. Useful environment variables

| var | default | meaning |
|---|---|---|
| `PC_ARCH` | `dino_vitb16` | backbone |
| `PC_IMG_SIZE` | 224 | must be a multiple of the patch size |
| `PC_PROTOS_PER_CLASS` | 10 | times num_classes = num_prototypes |
| `PC_EPOCHS` / `PC_WARM_EPOCHS` | 15 / 5 | total training epochs / warm-only prefix |
| `PC_FINETUNE_EPOCHS` | 20 | last-layer epochs after prototype masking |
| `PC_TRAIN_BATCH` | 48 | lower this first on CUDA OOM |
| `PC_LR_FEATURES` | 3e-5 | backbone lr, lowered from upstream's 1e-4 because a ViT finetunes at a smaller step than a ResNet |
| `PC_VISUALIZE` | 1 | set 0 to skip the prototype visualisation pass |
| `PC_SAVE_TARGET_ACCU` | 0.0 | see below |
| `PC_DEVICE` | auto | force `cpu` or `cuda:0` |

---

## 5. Two upstream behaviours worth knowing

**Checkpoints were silently discarded below 70% accuracy.** The finetune stage called
`save_model_w_condition(..., target_accu=0.70)`, so a harder dataset would train fully and
save *nothing*. The default is now `0.0`; raise it with `PC_SAVE_TARGET_ACCU` if you only
want good checkpoints kept.

**There is no push stage.** With `use_cap=True` (the ProtoConcepts default) `push_start` is
infinity and `push_epochs` is empty, so prototypes are never projected onto real training
patches. Visualisation instead counts how many prototypes are *visualisable*, and the
finetune stage masks the rest. That is the paper's contribution, not a misconfiguration.

---

## 6. What is and is not verified

Verified: construction and forward/backward for `dino_vitb16`, `dino_vits16` and
`dinov2_vitb14`; correct latent grids and receptive-field info; the full pipeline
(warm -> joint -> test -> visualise -> mask -> last-layer finetune) run to completion;
checkpoints written to separate per-dataset directories; and all five dataset configs
resolving with correct class detection and augmentation flags.

Not verified: absolute accuracy on any dataset, and GPU memory at the default batch size.
Watch the first joint epoch (epoch 5 by default) — that is when the backbone unfreezes and
memory peaks.
