"""Find the largest PC_TRAIN_BATCH that survives the JOINT phase.

Peak memory does not occur at epoch 0. During the warm phase (epochs < PC_WARM_EPOCHS)
`warm_only()` freezes the ViT backbone, so memory is small. At PC_WARM_EPOCHS the backbone
unfreezes and memory jumps several-fold. Sizing the batch from a warm-phase reading gives
an OOM exactly when joint training starts.

This runs real forward + loss + backward + optimizer steps with everything unfrozen -- the
joint phase -- and binary-searches the largest batch that fits your free memory.

    python3 calibrate_batch.py --num_classes 200 --protos_per_class 10 --gpu 0 --headroom_gb 3
"""
import argparse, gc, torch, torch.nn as nn


def try_batch(bs, a, device):
    gc.collect(); torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats(device)
    try:
        import model_ctrl_caps as M
        nproto = a.protos_per_class * a.num_classes
        net = M.construct_PPNet(base_architecture=a.arch, pretrained=False,
                                img_size=a.img_size, prototype_shape=(nproto, a.proto_depth, 1, 1),
                                cap_width=6.0, num_classes=a.num_classes,
                                prototype_activation_function='log',
                                add_on_layers_type='regular', last_layer_type='single').to(device)
        net = nn.DataParallel(net, device_ids=[device.index])
        # Joint phase: everything trainable.
        for p in net.module.parameters():
            p.requires_grad = True
        opt = torch.optim.Adam([
            {'params': net.module.features.parameters(), 'lr': 3e-5, 'weight_decay': 1e-3},
            {'params': net.module.add_on_layers.parameters(), 'lr': 3e-3, 'weight_decay': 1e-3},
            {'params': net.module.prototype_vectors, 'lr': 3e-3},
            {'params': net.module.last_layer.parameters(), 'lr': 1e-4},
        ])
        ce = nn.CrossEntropyLoss()
        clst_k = min(a.protos_per_class, a.protos_per_class)
        for _ in range(a.steps):
            x = torch.randn(bs, 3, a.img_size, a.img_size, device=device)
            y = torch.randint(0, a.num_classes, (bs,), device=device)
            opt.zero_grad(set_to_none=True)
            logits, min_distances = net(x)[:2]
            mask = torch.t(net.module.prototype_class_identity[:, y]).to(device)
            max_dist = net.module.prototype_shape[1] * net.module.prototype_shape[2] * net.module.prototype_shape[3]
            inv, _ = torch.topk((max_dist - min_distances) * mask, k=clst_k, dim=1)
            loss = ce(logits, y) + 0.8 * torch.mean(max_dist - inv) + 1e-4 * net.module.last_layer.weight.norm(p=1)
            loss.backward(); opt.step()
        return True, torch.cuda.max_memory_allocated(device) / 2**30
    except torch.cuda.OutOfMemoryError:
        return False, float('inf')
    except RuntimeError as e:
        if 'out of memory' in str(e).lower():
            return False, float('inf')
        raise
    finally:
        gc.collect(); torch.cuda.empty_cache()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--arch', default='dino_vitb16')
    p.add_argument('--img_size', type=int, default=224)
    p.add_argument('--num_classes', type=int, required=True)
    p.add_argument('--protos_per_class', type=int, default=10)
    p.add_argument('--proto_depth', type=int, default=128)
    p.add_argument('--gpu', type=int, default=0)
    p.add_argument('--headroom_gb', type=float, default=3.0)
    p.add_argument('--min_batch', type=int, default=4)
    p.add_argument('--max_batch', type=int, default=256)
    p.add_argument('--steps', type=int, default=3)
    a = p.parse_args()

    if not torch.cuda.is_available():
        raise SystemExit("No CUDA device available.")
    device = torch.device(f'cuda:{a.gpu}')
    torch.cuda.set_device(device)
    free, total = torch.cuda.mem_get_info(device)
    free_gb, total_gb = free / 2**30, total / 2**30
    budget = free_gb - a.headroom_gb
    print(f"GPU {a.gpu}: {torch.cuda.get_device_name(device)}")
    print(f"  total {total_gb:.1f} GiB, free {free_gb:.1f} GiB, others {total_gb-free_gb:.1f} GiB")
    print(f"  budget {budget:.1f} GiB | {a.arch} @{a.img_size}px, {a.num_classes} classes, "
          f"{a.protos_per_class*a.num_classes} prototypes, JOINT phase (all unfrozen)\n")

    lo, hi, best, bpeak = a.min_batch, a.max_batch, 0, 0.0
    while lo <= hi:
        mid = (lo + hi) // 2
        fits, peak = try_batch(mid, a, device)
        ok = fits and peak <= budget
        print(f"  batch {mid:4d} -> {f'{peak:.1f} GiB' if fits else 'OOM'}{'' if ok else '   too big'}", flush=True)
        if ok:
            best, bpeak = mid, peak; lo = mid + 1
        else:
            hi = mid - 1
    print()
    if not best:
        print(f"Even batch {a.min_batch} exceeded {budget:.1f} GiB. Free some memory or use dino_vits16.")
        return
    print(f"Largest joint-phase batch: PC_TRAIN_BATCH={best}  (peak {bpeak:.1f} GiB of {budget:.1f})")
    print(f"Suggested: PC_TRAIN_BATCH={best} PC_TEST_BATCH={int(best*1.5)}")


if __name__ == '__main__':
    main()
