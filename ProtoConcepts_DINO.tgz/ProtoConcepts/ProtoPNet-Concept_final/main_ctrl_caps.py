# ---------------------------------------------------------------------------------------
# CUDA_VISIBLE_DEVICES must be set BEFORE any torch import. The CUDA driver reads it when
# it first initialises, and an import that touches torch.cuda locks the process onto
# whatever was visible at that moment - which silently ignores -gpuid and sends every run
# to physical GPU 0. Parse the flag from argv by hand here; argparse runs further down.
import os as _os
import sys as _sys

_gpuid = '0'
for _i, _a in enumerate(_sys.argv):
    if _a == '-gpuid' and _i + 1 < len(_sys.argv):
        _gpuid = _sys.argv[_i + 1]
    elif _a.startswith('-gpuid='):
        _gpuid = _a.split('=', 1)[1]
_os.environ['CUDA_VISIBLE_DEVICES'] = _gpuid
print('CUDA_VISIBLE_DEVICES set to %s before importing torch' % _gpuid, flush=True)
# ---------------------------------------------------------------------------------------

import os
import shutil
import numpy as np
import torch
import torch.utils.data
# import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import vis_caps
import argparse
import re
from helpers import makedir
import model_ctrl_caps
import train_and_test_ctrl_caps as tnt
import save
from log import create_logger
from preprocess import mean, std, preprocess_input_function

parser = argparse.ArgumentParser()
parser.add_argument('-gpuid', nargs=1, type=str, default='0') # python3 main.py -gpuid=0,1,2,3
args = parser.parse_args()
# Already set at the top of this file, before torch was imported. Re-asserting it here
# would be a no-op (CUDA is initialised by now), so only verify it agrees.
if os.environ.get('CUDA_VISIBLE_DEVICES') != args.gpuid[0]:
    print('WARNING: -gpuid %s but CUDA_VISIBLE_DEVICES=%s' % (
        args.gpuid[0], os.environ.get('CUDA_VISIBLE_DEVICES')), flush=True)
print('CUDA_VISIBLE_DEVICES =', os.environ['CUDA_VISIBLE_DEVICES'])

# book keeping namings and code
from settings import base_architecture, img_size, prototype_shape, num_classes, \
                     prototype_activation_function, add_on_layers_type, experiment_run, last_layer_type
from settings import (dataset_name, num_workers, num_finetune_epochs, pin_memory,
                      persistent_workers, prefetch_factor, tf32,
                      save_target_accu, run_visualization, online_augment,
                      vflip, grayscale, color_jitter)

from settings import coefs

# load the data
from settings import train_dir, test_dir, train_push_dir, \
                     train_batch_size, test_batch_size, train_push_batch_size

base_architecture_type = re.match('^[a-z]*', base_architecture).group(0)

# Dataset tag in the path, so five datasets never overwrite each other's checkpoints.
model_dir = './saved_models/' + dataset_name + '/' + base_architecture + '/' + experiment_run + '/'
makedir(model_dir)
shutil.copy(src=os.path.join(os.getcwd(), __file__), dst=model_dir)
shutil.copy(src=os.path.join(os.getcwd(), 'settings.py'), dst=model_dir)
shutil.copy(src=os.path.join(os.getcwd(), base_architecture_type + '_features.py'), dst=model_dir)
shutil.copy(src=os.path.join(os.getcwd(), 'model_ctrl_caps.py'), dst=model_dir)
shutil.copy(src=os.path.join(os.getcwd(), 'train_and_test_ctrl_caps.py'), dst=model_dir)

log, logclose = create_logger(log_filename=os.path.join(model_dir, 'train.log'))

# Record the RESOLVED configuration. settings.py reads environment variables, so the copy
# of settings.py in this directory does not tell you what values a run actually used, and
# progress cannot be reported without knowing the epoch targets.
import json as _json
from settings import num_train_epochs as _nte, num_warm_epochs as _nwe
from settings import joint_optimizer_lrs, joint_lr_step_size, cap_width, clst_k
try:
    with open(os.path.join(model_dir, 'run_config.json'), 'w') as _f:
        _json.dump({'dataset': dataset_name, 'arch': base_architecture,
                    'num_classes': num_classes, 'prototype_shape': list(prototype_shape),
                    'img_size': img_size, 'num_train_epochs': _nte,
                    'num_warm_epochs': _nwe, 'num_finetune_epochs': num_finetune_epochs,
                    'train_dir': train_dir, 'test_dir': test_dir,
                    'train_batch_size': train_batch_size,
                    'save_target_accu': save_target_accu,
                    'joint_optimizer_lrs': joint_optimizer_lrs,
                    'joint_lr_step_size': joint_lr_step_size,
                    'coefs': coefs, 'cap_width': cap_width, 'clst_k': clst_k,
                    'protos_per_class': prototype_shape[0] // max(num_classes, 1),
                    'vflip': vflip, 'grayscale': grayscale, 'color_jitter': color_jitter},
                   _f, indent=2)
except Exception as _e:
    log('could not write run_config.json: %s' % _e)
log('base architecture: ' + base_architecture)
log('experiment run: ' + experiment_run)
img_dir = os.path.join(model_dir, 'img')
makedir(img_dir)
weight_matrix_filename = 'outputL_weights'
prototype_img_filename_prefix = 'prototype-img'
prototype_self_act_filename_prefix = 'prototype-self-act'
# PC_VIS_SAVE_IMAGES=0 runs the visualisation pass but writes NO PNGs. The pass still
# computes vis_count, which mask() needs to decide which prototypes are visualisable, so
# the post-mask accuracy and the visualisable fraction stay valid -- you only lose the
# picture files. This is what you want when the numbers matter and disk does not allow
# hundreds of thousands of PNGs. Contrast PC_VISUALIZE=0, which skips the pass entirely
# and makes mask() a no-op, so post-mask accuracy becomes meaningless.
if os.environ.get('PC_VIS_SAVE_IMAGES', '1').strip().lower() in ('0', 'false', 'no'):
    prototype_img_filename_prefix = None
    prototype_self_act_filename_prefix = None
    print('PC_VIS_SAVE_IMAGES=0: computing vis_count but writing no prototype PNGs',
          flush=True)
proto_bound_boxes_filename_prefix = 'bb'
seed = np.random.randint(10, 10000, size=1)[0]
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
print('current seed is:', seed)
normalize = transforms.Normalize(mean=mean,
                                 std=std)

_loader_kwargs = dict(num_workers=num_workers, pin_memory=pin_memory)
if num_workers > 0:
    _loader_kwargs['persistent_workers'] = persistent_workers
    _loader_kwargs['prefetch_factor'] = prefetch_factor
print('dataloader: %s' % _loader_kwargs, flush=True)

# all datasets
# train set
# Upstream points train_dir at a directory that was already augmented OFFLINE with
# Augmentor (rotation/skew/shear/flip, ~30x more images). With a plain train/ folder that
# augmentation has to happen online instead, or the model sees far less variation than the
# paper's recipe. The flags come from settings and are class-semantics decisions:
# vflip only for imagery with no canonical 'up', grayscale for intensity-only modalities,
# colour jitter only where colour varies within a class.
if online_augment:
    _train_steps = [
        transforms.Resize(size=(img_size + 32, img_size + 32)),
        transforms.RandomAffine(degrees=15, shear=10),
        transforms.RandomHorizontalFlip(),
    ]
    if vflip:
        _train_steps.append(transforms.RandomVerticalFlip())
    _train_steps.append(transforms.RandomCrop(img_size))
    if color_jitter > 0:
        _train_steps.append(transforms.ColorJitter(brightness=color_jitter,
                                                   contrast=color_jitter,
                                                   saturation=color_jitter))
    if grayscale:
        _train_steps.append(transforms.Grayscale(3))
    _train_steps += [transforms.ToTensor(), normalize]
    train_transform = transforms.Compose(_train_steps)
    print('online augmentation: affine+hflip'
          + (' +vflip' if vflip else '')
          + (' +jitter%.2f' % color_jitter if color_jitter > 0 else '')
          + (' +grayscale' if grayscale else ''), flush=True)
else:
    train_transform = transforms.Compose([
        transforms.Resize(size=(img_size, img_size)),
        transforms.ToTensor(),
        normalize,
    ])

train_dataset = datasets.ImageFolder(train_dir, train_transform)
train_loader = torch.utils.data.DataLoader(
    train_dataset, batch_size=train_batch_size, shuffle=True,
    **_loader_kwargs)
# push set
caps_push_dataset = datasets.ImageFolder(
    train_push_dir,
    transforms.Compose([
        transforms.Resize(size=(img_size, img_size)),
        transforms.ToTensor(),
    ]))
caps_push_loader = torch.utils.data.DataLoader(
    caps_push_dataset, batch_size=train_push_batch_size, shuffle=False,
    **_loader_kwargs)
# test set
test_dataset = datasets.ImageFolder(
    test_dir,
    transforms.Compose([
        transforms.Resize(size=(img_size, img_size)),
        transforms.ToTensor(),
        normalize,
    ]))
test_loader = torch.utils.data.DataLoader(
    test_dataset, batch_size=test_batch_size, shuffle=False,
    **_loader_kwargs)

# we should look into distributed sampler more carefully at torch.utils.data.distributed.DistributedSampler(train_dataset)
log('training set size: {0}'.format(len(train_loader.dataset)))
log('push set size: {0}'.format(len(caps_push_loader.dataset)))
log('test set size: {0}'.format(len(test_loader.dataset)))
log('batch size: {0}'.format(train_batch_size))

from settings import clst_k, cap_width
print('train with top-k cluster with k:', clst_k)
print('radius initialization is:',cap_width)
# construct the model
## resume ------------------------------------------------------------------------------
# ProtoConcepts has no resume path upstream, but its checkpoints are whole pickled models
# (torch.save(obj=model)), so one can be loaded and training continued.
#   PC_RESUME=/path/to/xx.pth   load this model instead of constructing a fresh one
#   PC_START_EPOCH=N            skip the first N epochs of the schedule
# The optimisers are rebuilt from scratch (their state is not in the checkpoint), so the
# first resumed epoch effectively restarts Adam's moment estimates. Set PC_START_EPOCH to
# the epoch AFTER the one in the checkpoint filename.
_resume = os.environ.get('PC_RESUME', '').strip()
start_epoch = int(os.environ.get('PC_START_EPOCH', '0'))
if _resume:
    if not os.path.isfile(_resume):
        raise SystemExit('PC_RESUME does not exist: %s' % _resume)
    # _nte, not num_train_epochs: the plain name is only imported further down (line ~262),
    # after this block runs.
    log('resuming from %s (starting at epoch %d of %d)' % (_resume, start_epoch, _nte))
    ppnet = torch.load(_resume, map_location='cpu', weights_only=False)
    log('loaded %d classes, %d prototypes' % (ppnet.num_classes, ppnet.num_prototypes))
    if ppnet.num_classes != num_classes:
        raise SystemExit('checkpoint has %d classes but this run expects %d'
                         % (ppnet.num_classes, num_classes))
else:
    ppnet = model_ctrl_caps.construct_PPNet(base_architecture=base_architecture,
                              pretrained=True, img_size=img_size,
                              prototype_shape=prototype_shape,
                              cap_width=cap_width,
                              num_classes=num_classes,
                              prototype_activation_function=prototype_activation_function,
                              add_on_layers_type=add_on_layers_type,
                              last_layer_type=last_layer_type)

import torch as _torch
_want = os.environ.get('PC_DEVICE', '').strip().lower()
device = _torch.device(_want) if _want else _torch.device('cuda' if _torch.cuda.is_available() else 'cpu')
if tf32 and torch.cuda.is_available():
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    log('TF32 matmuls enabled (PC_TF32=1)')
if device.type != 'cuda':
    log('WARNING: running on %s. Training ProtoConcepts on CPU is only useful as a smoke test.' % device)
ppnet = ppnet.to(device)
ppnet_multi = torch.nn.DataParallel(ppnet)
class_specific = True

# define optimizer
from settings import joint_optimizer_lrs, joint_lr_step_size
joint_optimizer_specs = \
    [{'params': ppnet.features.parameters(), 'lr': joint_optimizer_lrs['features'], 'weight_decay': 1e-3}, # bias are now also being regularized
    {'params': ppnet.add_on_layers.parameters(), 'lr': joint_optimizer_lrs['add_on_layers'], 'weight_decay': 1e-3},
    {'params': ppnet.prototype_vectors, 'lr': joint_optimizer_lrs['prototype_vectors']},
    ]

joint_optimizer = torch.optim.Adam(joint_optimizer_specs)
joint_lr_scheduler = torch.optim.lr_scheduler.StepLR(joint_optimizer, step_size=joint_lr_step_size, gamma=0.1)

from settings import warm_optimizer_lrs 

warm_optimizer_specs = \
    [{'params': ppnet.add_on_layers.parameters(), 'lr': warm_optimizer_lrs['add_on_layers'], 'weight_decay': 1e-3},
     {'params': ppnet.prototype_vectors, 'lr': warm_optimizer_lrs['prototype_vectors']},
     {'params': ppnet.cap_width_l2, 'lr': warm_optimizer_lrs['cap_width']},
    ]

warm_optimizer = torch.optim.Adam(warm_optimizer_specs)

# finetune
from settings import last_layer_optimizer_lr
last_layer_optimizer_specs = [{'params': ppnet.last_layer.parameters(), 'lr': last_layer_optimizer_lr}]
last_layer_optimizer = torch.optim.Adam(last_layer_optimizer_specs)# finetune



# number of training epochs, number of warm epochs, push start epoch, push epochs
from settings import num_train_epochs, num_warm_epochs, push_start, push_epochs

print(torch.cuda.get_device_name() if torch.cuda.is_available() else 'cpu')

# train the model
log('start training')
import copy

if start_epoch:
    log('skipping epochs 0..%d (PC_START_EPOCH)' % (start_epoch - 1))
for epoch in range(start_epoch, num_train_epochs):
    log('epoch: \t{0}'.format(epoch))

    if epoch < num_warm_epochs:
        tnt.warm_only(model=ppnet_multi, log=log)
        _ = tnt.train(model=ppnet_multi, dataloader=train_loader, optimizer=warm_optimizer,
                    class_specific=class_specific, clst_k = clst_k, coefs=coefs, log=log)
    else:
        tnt.joint(model=ppnet_multi, log=log)
        _ = tnt.train(model=ppnet_multi, dataloader=train_loader, optimizer=joint_optimizer,
                    class_specific=class_specific, clst_k = clst_k, coefs=coefs, log=log)
        joint_lr_scheduler.step()

    accu = tnt.test(model=ppnet_multi, dataloader=test_loader,
                    class_specific=class_specific, log=log)
    if torch.cuda.is_available():
        _free, _total = torch.cuda.mem_get_info()
        log('GPU peak this epoch: %.1f GiB allocated, %.1f GiB reserved, %.1f/%.1f GiB used on card'
            % (torch.cuda.max_memory_allocated()/2**30, torch.cuda.max_memory_reserved()/2**30,
               (_total-_free)/2**30, _total/2**30))
        torch.cuda.reset_peak_memory_stats()
    save.save_model_w_condition(model=ppnet, model_dir=model_dir, model_name=str(epoch) + 'nofinetune', accu=accu,
                                target_accu=save_target_accu, log=log)
# visualization
if not run_visualization:
    # Masking needs a per-prototype visualisable count; with no visualisation pass, treat
    # every prototype as visualisable so the finetune stage still runs.
    vis_count = torch.ones(ppnet.num_prototypes)
    log('skipping prototype visualisation (PC_VISUALIZE=0)')
with torch.no_grad():
  if run_visualization:
    vis_count = vis_caps.vis_prototypes(
            caps_push_loader, # pytorch dataloader (must be unnormalized in [0,1])
            prototype_network_parallel=ppnet_multi, # pytorch network with prototype_vectors
            class_specific=class_specific,
            preprocess_input_function=preprocess_input_function, # normalize if needed
            prototype_layer_stride=1,
            root_dir_for_saving_prototypes=img_dir, # if not None, prototypes will be saved here
            epoch_number=10, # if not provided, prototypes saved previously will be overwritten
            prototype_img_filename_prefix=prototype_img_filename_prefix,
            prototype_self_act_filename_prefix=prototype_self_act_filename_prefix,
            proto_bound_boxes_filename_prefix=proto_bound_boxes_filename_prefix,
            save_prototype_class_identity=True,
            ltwo=True,
            log=log)

# mask
ppnet_multi.module.mask(vis_count)
num = (vis_count > 0).sum()
#finetune
print('The estimated number of visualizable prototypes:')
print(num)
print()
tnt.last_only(model=ppnet_multi, log=log)
for epoch in range(num_finetune_epochs):
    log('iteration: \t{0}'.format(epoch))
    _= tnt.train(model=ppnet_multi, dataloader=train_loader, optimizer=last_layer_optimizer,
                  class_specific=class_specific, coefs=coefs, log=log)
    print('Accuracy is:')
    accu= tnt.test(model=ppnet_multi, dataloader=test_loader,
                    class_specific=class_specific, log=log)
    save.save_model_w_condition(model=ppnet, model_dir=model_dir, model_name=str(epoch) + '_topk_' + 'finetuned', accu=accu,
                                target_accu=save_target_accu, log=log)
   
logclose()

