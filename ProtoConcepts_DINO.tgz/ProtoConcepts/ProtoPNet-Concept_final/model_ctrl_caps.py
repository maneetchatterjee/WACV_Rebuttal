import pdb

import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
import torch.nn.functional as F
import numpy as np
from resnet_features import resnet18_features, resnet34_features, resnet50_features, resnet50_features_inat, resnet101_features, resnet152_features
from densenet_features import densenet121_features, densenet161_features, densenet169_features, densenet201_features
from vgg_features import vgg11_features, vgg11_bn_features, vgg13_features, vgg13_bn_features, vgg16_features, vgg16_bn_features,\
                         vgg19_features, vgg19_bn_features
from dino_features import (dino_vitb16_features, dino_vits16_features, dino_vitb8_features,
                          dino_vits8_features, dinov2_vitb14_features, dinov2_vits14_features,
                          is_dino_net)

from receptive_field import compute_proto_layer_rf_info_v2

# --- device helper (added for the DINO port) -------------------------------------------
import os as _os
import torch as _torch

_PC_DEV_CACHE = []


def _pc_dev():
    """Resolve the device LAZILY.

    This must never run at import time: torch.cuda.is_available() initialises the CUDA
    driver, and main_ctrl_caps.py sets CUDA_VISIBLE_DEVICES *after* its imports. Touching
    CUDA during import therefore locks the process onto physical GPU 0 and silently
    ignores -gpuid.
    """
    if not _PC_DEV_CACHE:
        want = _os.environ.get('PC_DEVICE', '').strip().lower()
        if want:
            _PC_DEV_CACHE.append(_torch.device(want))
        else:
            _PC_DEV_CACHE.append(
                _torch.device('cuda' if _torch.cuda.is_available() else 'cpu'))
    return _PC_DEV_CACHE[0]
# --------------------------------------------------------------------------------------


base_architecture_to_features = {'resnet18': resnet18_features,
                                 'resnet34': resnet34_features,
                                 'resnet50': resnet50_features,
                                 'resnet50_inat': resnet50_features_inat,
                                 'resnet101': resnet101_features,
                                 'resnet152': resnet152_features,
                                 'densenet121': densenet121_features,
                                 'densenet161': densenet161_features,
                                 'densenet169': densenet169_features,
                                 'densenet201': densenet201_features,
                                 'vgg11': vgg11_features,
                                 'vgg11_bn': vgg11_bn_features,
                                 'vgg13': vgg13_features,
                                 'vgg13_bn': vgg13_bn_features,
                                 'vgg16': vgg16_features,
                                 'vgg16_bn': vgg16_bn_features,
                                 'vgg19': vgg19_features,
                                 'vgg19_bn': vgg19_bn_features,
                                 'dino_vitb16': dino_vitb16_features,
                                 'dino_vits16': dino_vits16_features,
                                 'dino_vitb8': dino_vitb8_features,
                                 'dino_vits8': dino_vits8_features,
                                 'dinov2_vitb14': dinov2_vitb14_features,
                                 'dinov2_vits14': dinov2_vits14_features}

class PPNet(nn.Module):

    def __init__(self, features, img_size, prototype_shape, cap_width,
                 proto_layer_rf_info, num_classes, init_weights=True,
                 prototype_activation_function='log',
                 add_on_layers_type='bottleneck',
                 last_layer_type='single'):

        super(PPNet, self).__init__()
        self.img_size = img_size
        self.prototype_shape = prototype_shape
        self.num_prototypes = prototype_shape[0]
        self.num_classes = num_classes
        self.epsilon = 1e-4
        self.max_act_l2 = torch.log(torch.tensor(1)/self.epsilon)

        # cap_width must stay below max_act_l2 = log(1/epsilon) ~= 9.21. Activations are
        # gated by clamp(max_act_l2 - Softplus(cap_width_l2), min=0); once cap_width
        # reaches max_act_l2 that gate is 0, every patch of every image counts as fully
        # activated, no prototype discriminates anything, and the model emits a constant
        # prediction from epoch 0 while training "successfully" for hundreds of epochs.
        # Clamp with a loud warning rather than letting a run silently produce nothing.
        _max_cap = float(self.max_act_l2) * 0.9
        if cap_width >= _max_cap:
            print('WARNING: cap_width=%.2f is at or above the usable ceiling %.2f '
                  '(max_act_l2=%.2f = log(1/epsilon)). Clamping to %.2f. Values at or above '
                  'the ceiling collapse the model to a constant predictor.'
                  % (cap_width, _max_cap, float(self.max_act_l2), _max_cap), flush=True)
            cap_width = _max_cap
        self.cap_width_l2 = nn.Parameter(cap_width * torch.ones(1, self.num_prototypes),
                                        requires_grad=True)
        self.cap_activation_l2 = nn.Softplus()
        self.masked = False

        # prototype_activation_function could be 'log', 'linear',
        # or a generic function that converts distance to similarity score
        self.prototype_activation_function = prototype_activation_function
        self.non_vis_mask = nn.Parameter(torch.ones(self.num_prototypes),
                                 requires_grad=False)
        '''
        Here we are initializing the class identities of the prototypes
        Without domain specific knowledge we allocate the same number of
        prototypes for each class
        '''
        assert(self.num_prototypes % self.num_classes == 0)
        # a onehot indication matrix for each prototype's class identity
        self.prototype_class_identity = torch.zeros(self.num_prototypes,
                                                    self.num_classes)

        num_prototypes_per_class = self.num_prototypes // self.num_classes
        for j in range(self.num_prototypes):
            self.prototype_class_identity[j, j // num_prototypes_per_class] = 1

        self.proto_layer_rf_info = proto_layer_rf_info

        # this has to be named features to allow the precise loading
        self.features = features

        features_name = str(self.features).upper()
        if features_name.startswith('DINO'):
            # patch_embed.proj is the FIRST conv in a ViT, not the last, so the Conv2d
            # heuristic below would read the wrong layer. The wrapper reports its width.
            first_add_on_layer_in_channels = self.features.out_channels
        elif features_name.startswith('VGG') or features_name.startswith('RES'):
            first_add_on_layer_in_channels = \
                [i for i in features.modules() if isinstance(i, nn.Conv2d)][-1].out_channels
        elif features_name.startswith('DENSE'):
            first_add_on_layer_in_channels = \
                [i for i in features.modules() if isinstance(i, nn.BatchNorm2d)][-1].num_features
        else:
            raise Exception('other base base_architecture NOT implemented')

        if add_on_layers_type == 'bottleneck':
            add_on_layers = []
            current_in_channels = first_add_on_layer_in_channels
            while (current_in_channels > self.prototype_shape[1]) or (len(add_on_layers) == 0):
                current_out_channels = max(self.prototype_shape[1], (current_in_channels // 2))
                add_on_layers.append(nn.Conv2d(in_channels=current_in_channels,
                                               out_channels=current_out_channels,
                                               kernel_size=1))
                add_on_layers.append(nn.ReLU())
                add_on_layers.append(nn.Conv2d(in_channels=current_out_channels,
                                               out_channels=current_out_channels,
                                               kernel_size=1))
                if current_out_channels > self.prototype_shape[1]:
                    add_on_layers.append(nn.ReLU())
                else:
                    assert(current_out_channels == self.prototype_shape[1])
                    add_on_layers.append(nn.Sigmoid())
                current_in_channels = current_in_channels // 2
            self.add_on_layers = nn.Sequential(*add_on_layers)
        elif add_on_layers_type == 'nosig':
            self.add_on_layers = nn.Sequential(
                nn.Conv2d(in_channels=first_add_on_layer_in_channels, 
                out_channels=self.prototype_shape[1], 
                kernel_size=1),
                nn.ReLU(),
                nn.Conv2d(in_channels=self.prototype_shape[1], 
                out_channels=self.prototype_shape[1], 
                kernel_size=1)
                )
        elif add_on_layers_type == 'regular': 
            self.add_on_layers = nn.Sequential(
                nn.Conv2d(in_channels=first_add_on_layer_in_channels, out_channels=self.prototype_shape[1], kernel_size=1),
                nn.ReLU(),
                nn.Conv2d(in_channels=self.prototype_shape[1], out_channels=self.prototype_shape[1], kernel_size=1),
                nn.Sigmoid()
                )
        elif add_on_layers_type == 'none': 
            self.add_on_layers = nn.Identity()
        else: 
            print('idk i havent programmed this yet')
        
        self.prototype_vectors = nn.Parameter(torch.rand(self.prototype_shape),
                                              requires_grad=True)

        # do not make this just a tensor,
        # since it will not be moved automatically to gpu
        self.ones = nn.Parameter(torch.ones(self.prototype_shape),
                                 requires_grad=False)
        self.last_layer_type = last_layer_type

        if self.last_layer_type == 'single':
            self.last_layer = nn.Linear(self.num_prototypes, self.num_classes,
                                        bias=False) # do not use bias
        elif self.last_layer_type == 'multi': 
            self.last_layer = nn.Sequential(
                                nn.Linear(self.num_prototypes, int(self.num_prototypes/2), bias=False),
                                nn.Linear(int(self.num_prototypes/2), self.num_classes, bias=False)
                                )
        else: 
            print('invalid last layer type')

        if init_weights:
            self._initialize_weights()

    def conv_features(self, x, debug=False):
        '''
        the feature input to prototype layer
        '''
        x = self.features(x)
        if debug: 
            print('features output', x)
        x = self.add_on_layers(x)
        return x

    def _l2_convolution(self, x):
        '''
        apply self.prototype_vectors as l2-convolution filters on input x
        '''
        x2 = x ** 2
        x2_patch_sum = F.conv2d(input=x2, weight=self.ones)

        p2 = self.prototype_vectors ** 2
        p2 = torch.sum(p2, dim=(1, 2, 3))
        # p2 is a vector of shape (num_prototypes,)
        # then we reshape it to (num_prototypes, 1, 1)
        p2_reshape = p2.view(-1, 1, 1)

        xp = F.conv2d(input=x, weight=self.prototype_vectors)
        intermediate_result = - 2 * xp + p2_reshape  # use broadcast
        # x2_patch_sum and intermediate_result are of the same shape
        distances = F.relu(x2_patch_sum + intermediate_result)
        return distances

    def prototype_distances(self, x):
        '''
        x is the raw input
        '''
        conv_features = self.conv_features(x)
        distances = self._l2_convolution(conv_features)
        return distances

    def distance_2_similarity(self, distances):
        if self.prototype_activation_function == 'log':
            return torch.log((distances + 1) / (distances + self.epsilon))
        elif self.prototype_activation_function == 'linear':
            return -distances
        else:
            return self.prototype_activation_function(distances)

    def soft_clamp(self, x, val=1.0, upper=True): 
        if upper: 
            return torch.min(x, val + x - x.detach())
        else: 
            return torch.max(x, val + x - x.detach())

    def forward(self, x, get_act=False, vis_cap=False):
        batch_size = x.size(0)
        if not vis_cap:
            distances = self.prototype_distances(x)
            distances = distances.view(batch_size, self.num_prototypes, -1)
            min_distances, _ = torch.min(distances, 2)
            min_distances = min_distances.view(-1, self.num_prototypes)
            prototype_activations = self.distance_2_similarity(min_distances)
            #This should enforce the cap while keeping things on the same scale
            cap_factor = self.cap_activation_l2(self.cap_width_l2)
            prototype_activations = self.soft_clamp(prototype_activations + cap_factor, 
            val=self.max_act_l2, upper=True) - cap_factor.detach()
            if self.masked:
                prototype_activations = self.non_vis_mask*prototype_activations.clone()
            logits = self.last_layer(prototype_activations)
        elif vis_cap: 
            distances = self.prototype_distances(x)
            big_proto_act = self.distance_2_similarity(distances)
            cap_factor = self.cap_activation_l2(self.cap_width_l2).unsqueeze(2).unsqueeze(3)
            big_proto_act_capped = self.soft_clamp(big_proto_act + cap_factor, val=self.max_act_l2, upper=True) \
                                        - cap_factor.detach()
            return big_proto_act, cap_factor
        
        if get_act: 
            return prototype_activations, cap_factor
        else: 
            return logits, min_distances

    def proto_unit_loss(self): 
        #Seeks to constrain prototypes to lie within the unit hypercube (between 0 and 1)
        return torch.mean(F.relu(self.prototype_vectors - 1.)) + torch.mean(F.relu(-1 * self.prototype_vectors))

    def push_forward(self, x):
        '''this method is needed for the pushing operation'''
        conv_output = self.conv_features(x)
        distances = self._l2_convolution(conv_output)
        return conv_output, distances

    def prune_duplicates(self): 
        dup_ind = torch.zeros(self.num_prototypes, self.num_prototypes)
        prototypes_to_prune = []

        #indicate duplicates
        for i in range(self.num_prototypes): 
            if dup_ind[:, i].sum() == 0.: 
                for j in range(i + 1, ((i // 10) + 1) * 10): 
                    if torch.equal(self.prototype_vectors[i], self.prototype_vectors[j]): 
                        dup_ind[i][j] = 1. 
                        prototypes_to_prune.append(j)

        dup_ind = dup_ind + torch.diag(torch.ones(self.num_prototypes))
        dup_ind = dup_ind.to(_pc_dev())

        #rearrange last layer
        ll_weights = torch.t(self.last_layer.weight.data.clone())
        new_ll_weights = torch.matmul(dup_ind, ll_weights)
        self.last_layer.weight.data.copy_(torch.t(new_ll_weights))

        print('found ' + str(len(prototypes_to_prune)) + ' duplicates')

        #prune duplicates
        self.prune_prototypes(prototypes_to_prune)

    def mask(self, stats_arr):
        non_vis_proto = np.argwhere(stats_arr == 0).flatten() # the nonvis prototype idx 
        new_mask = torch.ones(self.num_prototypes).to(_pc_dev())
        new_mask[non_vis_proto]  = 0.0
        self.non_vis_mask = nn.Parameter(new_mask,
                                 requires_grad=False)
        self.masked = True
        # sanity check 
        assert(torch.all(self.non_vis_mask[non_vis_proto] == 0.0))

    def prune_prototypes(self, prototypes_to_prune):
        '''
        prototypes_to_prune: a list of indices each in
        [0, current number of prototypes - 1] that indicates the prototypes to
        be removed
        '''
        prototypes_to_keep = list(set(range(self.num_prototypes)) - set(prototypes_to_prune))

        self.prototype_vectors = nn.Parameter(self.prototype_vectors.data[prototypes_to_keep, ...],
                                              requires_grad=True)

        self.prototype_shape = list(self.prototype_vectors.size())
        self.num_prototypes = self.prototype_shape[0]

        # changing self.last_layer in place
        # changing in_features and out_features make sure the numbers are consistent
        self.last_layer.in_features = self.num_prototypes
        self.last_layer.out_features = self.num_classes
        self.last_layer.weight.data = self.last_layer.weight.data[:, prototypes_to_keep]

        # self.ones is nn.Parameter
        self.ones = nn.Parameter(self.ones.data[prototypes_to_keep, ...],
                                 requires_grad=False)
        # self.prototype_class_identity is torch tensor
        # so it does not need .data access for value update
        self.prototype_class_identity = self.prototype_class_identity[prototypes_to_keep, :]
        self.cap_width_l2.data = self.cap_width_l2.data[:, prototypes_to_keep]

    def __repr__(self):
        # PPNet(self, features, img_size, prototype_shape,
        # proto_layer_rf_info, num_classes, init_weights=True):
        rep = (
            'PPNet(\n'
            '\tfeatures: {},\n'
            '\timg_size: {},\n'
            '\tprototype_shape: {},\n'
            '\tproto_layer_rf_info: {},\n'
            '\tnum_classes: {},\n'
            '\tepsilon: {}\n'
            ')'
        )

        return rep.format(self.features,
                          self.img_size,
                          self.prototype_shape,
                          self.proto_layer_rf_info,
                          self.num_classes,
                          self.epsilon)

    def zero_negative_connections(self): 
        positive_one_weights_locations = torch.t(self.prototype_class_identity).to(_pc_dev())
        self.last_layer.weight.data.copy_(
            self.last_layer.weight.data * positive_one_weights_locations)

    def set_last_layer_incorrect_connection(self, incorrect_strength):
        '''
        the incorrect strength will be actual strength if -0.5 then input -0.5
        '''
        if self.last_layer_type == 'single':
            positive_one_weights_locations = torch.t(self.prototype_class_identity)
            negative_one_weights_locations = 1 - positive_one_weights_locations

            correct_class_connection = 1
            incorrect_class_connection = incorrect_strength
            self.last_layer.weight.data.copy_(
                correct_class_connection * positive_one_weights_locations
                + incorrect_class_connection * negative_one_weights_locations)
        elif self.last_layer_type == 'multi': 
            first_weight = torch.zeros(int(self.num_prototypes/2), self.num_prototypes)
            for i in range(int(self.num_prototypes/2)):
                first_weight[i][2*i]=1
                first_weight[i][2*i+1]=1
            second_weight = torch.zeros(self.num_classes, int(self.num_prototypes/2))
            npc = (int(self.num_prototypes/2)) // self.num_classes
            for j in range(self.num_prototypes):
                second_weight[j // npc, j] = 1
                second_weight = second_weight + (1 - second_weight) * -0.5
            self.last_layer[0].weight.data.copy_(first_weight)
            self.last_layer[1].weight.data.copy_(second_weight)    
        else: 
            print('invalid last layer type')

    def _initialize_weights(self):
        for m in self.add_on_layers.modules():
            if isinstance(m, nn.Conv2d):
                # every init technique has an underscore _ in the name
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')

                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

        self.set_last_layer_incorrect_connection(incorrect_strength=-0.5)



def construct_PPNet(base_architecture, pretrained=True, img_size=224,
                    prototype_shape=(2000, 512, 1, 1), cap_width=7.5, num_classes=200,
                    prototype_activation_function='log',
                    add_on_layers_type='bottleneck',
                    last_layer_type='single'):
    features = base_architecture_to_features[base_architecture](pretrained=pretrained)
    layer_filter_sizes, layer_strides, layer_paddings = features.conv_info()
    proto_layer_rf_info = compute_proto_layer_rf_info_v2(img_size=img_size,
                                                         layer_filter_sizes=layer_filter_sizes,
                                                         layer_strides=layer_strides,
                                                         layer_paddings=layer_paddings,
                                                         prototype_kernel_size=prototype_shape[2])
    return PPNet(features=features,
                 img_size=img_size,
                 prototype_shape=prototype_shape,
                 cap_width=cap_width,
                 proto_layer_rf_info=proto_layer_rf_info,
                 num_classes=num_classes,
                 init_weights=True,
                 prototype_activation_function=prototype_activation_function,
                 add_on_layers_type=add_on_layers_type,
                 last_layer_type=last_layer_type)

