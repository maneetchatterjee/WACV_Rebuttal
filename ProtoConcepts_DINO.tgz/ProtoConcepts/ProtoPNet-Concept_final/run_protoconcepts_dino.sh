#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# ProtoConcepts (ProtoPNet-Concept, NeurIPS 2023) with a DINO ViT backbone.
#
#   DATASET=cub    bash run_protoconcepts_dino.sh
#   DATASET=gbcu   bash run_protoconcepts_dino.sh
#   DATASET=aid    bash run_protoconcepts_dino.sh
#   DATASET=car    bash run_protoconcepts_dino.sh
#   DATASET=flower bash run_protoconcepts_dino.sh
#
# Checkpoints go to ./saved_models/<dataset>/<arch>/<run>/ so datasets never collide.
# Every setting is an environment variable; see settings.py for the full list.
# ---------------------------------------------------------------------------
set -euo pipefail

DATASET="${DATASET:-cub}"
GPU="${GPU:-0}"
export PC_ARCH="${PC_ARCH:-dino_vitb16}"
export PC_IMG_SIZE="${PC_IMG_SIZE:-224}"
export PC_PROTOS_PER_CLASS="${PC_PROTOS_PER_CLASS:-10}"
export PC_NUM_WORKERS="${PC_NUM_WORKERS:-8}"
export PC_LAYOUT="${PC_LAYOUT:-imagefolder}"

case "$DATASET" in
  cub|CUB)
    export PC_DATASET=cub
    export PC_DATA_PATH="${DATA_PATH:-/home/paul/Paul/DATASETS/CUB}"
    ;;
  gbcu|GBCU)
    export PC_DATASET=gbcu
    export PC_DATA_PATH="${DATA_PATH:-/home/paul/Paul/DATASETS/GBCU}"
    # Ultrasound is intensity-only. Unset if your scans carry colour Doppler overlays.
    export PC_GRAY="${PC_GRAY:-1}"
    ;;
  aid|AID)
    export PC_DATASET=aid
    export PC_DATA_PATH="${DATA_PATH:-/home/paul/Paul/DATASETS/aid}"
    # Aerial imagery has no canonical 'up', so vertical flips are valid here only.
    export PC_VFLIP="${PC_VFLIP:-1}"
    ;;
  car|CAR|cars|CARS)
    export PC_DATASET=car
    export PC_DATA_PATH="${DATA_PATH:-/home/paul/Paul/DATASETS/car}"
    # Two cars of the same model differ in paint colour, so jitter colour here.
    export PC_COLOR_JITTER="${PC_COLOR_JITTER:-0.3}"
    ;;
  flower|FLOWER|flowers|flowers102)
    export PC_DATASET=flower
    # The ImageFolder tree sits inside flowers102_split/; setid.mat is unused.
    export PC_DATA_PATH="${DATA_PATH:-/home/paul/Paul/DATASETS/flower/flowers102_split}"
    # Colour is class-defining for flowers: do NOT jitter it.
    export PC_COLOR_JITTER="${PC_COLOR_JITTER:-0.0}"
    ;;
  *)
    export PC_DATASET="$DATASET"
    export PC_DATA_PATH="${DATA_PATH:?Set DATA_PATH=/path/to/dataset for a custom dataset}"
    ;;
esac

# Class count is read off the directory tree rather than hardcoded, because
# num_prototypes must be an exact multiple of num_classes or the model asserts.
TRAIN_DIR="$PC_DATA_PATH/train"
if [ ! -d "$TRAIN_DIR" ]; then
  echo "ERROR: $TRAIN_DIR does not exist. Check DATA_PATH." >&2
  exit 1
fi
DETECTED=$(find "$TRAIN_DIR" -mindepth 1 -maxdepth 1 -type d | wc -l)
export PC_NUM_CLASSES="${PC_NUM_CLASSES:-$DETECTED}"
if [ "$PC_NUM_CLASSES" -lt 2 ]; then
  echo "ERROR: found $PC_NUM_CLASSES class folders in $TRAIN_DIR." >&2
  exit 1
fi

export PC_TRAIN_BATCH="${PC_TRAIN_BATCH:-48}"
export PC_TEST_BATCH="${PC_TEST_BATCH:-64}"
export PC_PUSH_BATCH="${PC_PUSH_BATCH:-48}"
export PC_EPOCHS="${PC_EPOCHS:-15}"
export PC_WARM_EPOCHS="${PC_WARM_EPOCHS:-5}"
export PC_FINETUNE_EPOCHS="${PC_FINETUNE_EPOCHS:-20}"
export PC_VISUALIZE="${PC_VISUALIZE:-1}"
export PC_SAVE_TARGET_ACCU="${PC_SAVE_TARGET_ACCU:-0.0}"
export PC_RUN_NAME="${PC_RUN_NAME:-arr}"

NPROTO=$(( PC_PROTOS_PER_CLASS * PC_NUM_CLASSES ))
echo "=============================================================="
echo " ProtoConcepts + DINO"
echo "   dataset      : $PC_DATASET  ($PC_DATA_PATH)"
echo "   classes      : $PC_NUM_CLASSES (detected from $TRAIN_DIR)"
echo "   prototypes   : $NPROTO  ($PC_PROTOS_PER_CLASS per class)"
echo "   backbone     : $PC_ARCH @ ${PC_IMG_SIZE}px"
echo "   epochs       : $PC_WARM_EPOCHS warm + $(( PC_EPOCHS - PC_WARM_EPOCHS )) joint, then $PC_FINETUNE_EPOCHS last-layer"
echo "   batch        : $PC_TRAIN_BATCH train / $PC_TEST_BATCH test"
echo "   gpu          : $GPU"
echo "   checkpoints  : ./saved_models/$PC_DATASET/$PC_ARCH/$PC_RUN_NAME/"
echo "   augment      : vflip=${PC_VFLIP:-0} gray=${PC_GRAY:-0} jitter=${PC_COLOR_JITTER:-0.0}"
echo "=============================================================="

python3 -u main_ctrl_caps.py -gpuid "$GPU"

echo "Finished. Checkpoints in ./saved_models/$PC_DATASET/$PC_ARCH/$PC_RUN_NAME/"
echo "  training log : ./saved_models/$PC_DATASET/$PC_ARCH/$PC_RUN_NAME/train.log"
echo "  prototypes   : ./saved_models/$PC_DATASET/$PC_ARCH/$PC_RUN_NAME/img/"
