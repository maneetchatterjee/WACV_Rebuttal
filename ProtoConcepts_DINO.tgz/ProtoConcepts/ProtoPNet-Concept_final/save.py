import glob
import os
import re
import shutil
import tempfile

import torch

# A truncated .pth is worse than no .pth: it looks like a result and fails at load time.
# Anything smaller than this is treated as invalid.
MIN_VALID_BYTES = 1 << 20  # 1 MiB


def _flag(name, default='1'):
    return os.environ.get(name, default).strip().lower() not in ('0', 'false', 'no')


def is_valid_checkpoint(path):
    try:
        return os.path.isfile(path) and os.path.getsize(path) >= MIN_VALID_BYTES
    except OSError:
        return False


def accu_in_name(path):
    m = re.search(r'([01]\.\d{4})\.pth$', os.path.basename(path))
    return float(m.group(1)) if m else None


def free_gib(path):
    try:
        return shutil.disk_usage(path).free / 2 ** 30
    except OSError:
        return float('inf')


def save_model_w_condition(model, model_dir, model_name, accu, target_accu, log=print):
    '''
    model: this is not the multigpu model

    Each file is a whole pickled model (torch.save(obj=model)), not a state_dict, so a
    ViT-B/16 with 2000 prototypes is ~350 MB. Three protections against the failure mode
    where a full disk both corrupts a checkpoint and kills the run:

      1. keep only the best file per family (PC_SAVE_BEST_ONLY=1, default) and delete
         superseded ones AFTER the new file is safely on disk;
      2. write to a temporary file and rename into place, so an interrupted or failed write
         never leaves a half-written .pth behind;
      3. a failed save is logged and swallowed rather than raised, so running out of disk
         costs you one checkpoint instead of the whole run.
    '''
    if accu <= target_accu:
        return

    family = re.sub(r'^\d+', '', model_name)
    best_only = _flag('PC_SAVE_BEST_ONLY')

    # Skip the write entirely when it cannot improve on what is already stored. Upstream
    # wrote one ~350 MB file per epoch; a 183-epoch run filled a 1.9 TB volume. Checking
    # first means exactly one file per family survives AND we never spend the I/O on a
    # file we would immediately delete.
    if best_only and family:
        existing = [(accu_in_name(f), f) for f in
                    glob.glob(os.path.join(model_dir, '*' + family + '*.pth'))]
        existing = [(a, f) for a, f in existing if a is not None and is_valid_checkpoint(f)]
        if existing:
            best_a, best_f = max(existing)
            if accu <= best_a:
                log('\tnot saved: {0:.4f} does not beat stored {1:.4f} ({2})'.format(
                    accu, best_a, os.path.basename(best_f)))
                return

    log('\tabove {0:.2f}%'.format(target_accu * 100))
    final_path = os.path.join(model_dir, (model_name + '{0:.4f}.pth').format(accu))

    avail = free_gib(model_dir)
    if avail < 2.0:
        log('\tWARNING: only {0:.1f} GiB free on the checkpoint volume.'.format(avail))

    tmp_fd, tmp_path = tempfile.mkstemp(suffix='.pth.tmp', dir=model_dir)
    os.close(tmp_fd)
    try:
        torch.save(obj=model, f=tmp_path)
        if not is_valid_checkpoint(tmp_path):
            raise OSError('checkpoint wrote only {0} bytes'.format(os.path.getsize(tmp_path)))
        os.replace(tmp_path, final_path)   # atomic on POSIX
    except Exception as e:
        # Do not let a disk problem take down a run that is otherwise training fine.
        log('\tWARNING: failed to save checkpoint ({0}: {1}). '
            'Training continues; {2:.1f} GiB free.'.format(type(e).__name__, e, free_gib(model_dir)))
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        return

    if best_only and family:
        # The new file is the best in its family (checked above), so every sibling can go.
        # family = model_name with the leading epoch number stripped, e.g.
        # "19_topk_finetuned" -> "_topk_finetuned", "5nofinetune" -> "nofinetune"
        removed = 0
        for f in glob.glob(os.path.join(model_dir, '*' + family + '*.pth')):
            if os.path.abspath(f) == os.path.abspath(final_path):
                continue
            a = accu_in_name(f)
            if (a is not None and a <= accu) or not is_valid_checkpoint(f):
                try:
                    os.remove(f)
                    removed += 1
                except OSError:
                    pass
        if removed:
            log('\tpruned {0} superseded/invalid {1} checkpoint(s)'.format(removed, family))
