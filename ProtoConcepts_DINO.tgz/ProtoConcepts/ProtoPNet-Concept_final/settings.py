"""ProtoConcepts settings, driven by environment variables.

Upstream hardcoded every value here and exposed only -gpuid on the command line, which
makes running five datasets impossible without editing the file between runs. Every
setting below now reads an environment variable with the original value as its default,
so `run_protoconcepts_dino.sh` can drive it and nothing changes if you set nothing.

Required per dataset:
    PC_DATASET      short tag used in the checkpoint path, e.g. cub / gbcu / aid / car / flower
    PC_DATA_PATH    dataset root containing train/ and val/ (or test/)
    PC_NUM_CLASSES  number of classes

Key constraint: num_prototypes must be divisible by num_classes, because ProtoPNet
allocates an equal number of prototypes to each class. PC_PROTOS_PER_CLASS (default 10,
as in the paper's CUB config) is multiplied by num_classes to get num_prototypes.
"""
import os


def _s(name, default):
    return os.environ.get(name, default)


def _i(name, default):
    return int(os.environ.get(name, default))


def _f(name, default):
    return float(os.environ.get(name, default))


def _b(name, default):
    v = os.environ.get(name)
    return default if v is None else v.strip().lower() in ('1', 'true', 'yes', 'on')


# ---------------------------------------------------------------- dataset / backbone
dataset_name = _s('PC_DATASET', 'cub')
base_architecture = _s('PC_ARCH', 'dino_vitb16')
img_size = _i('PC_IMG_SIZE', 224)
num_classes = _i('PC_NUM_CLASSES', 200)

prototype_activation_function = 'log'
add_on_layers_type = _s('PC_ADD_ON', 'regular')
temp = 5.0

# num_prototypes must be an exact multiple of num_classes (asserted in model_ctrl_caps).
protos_per_class = _i('PC_PROTOS_PER_CLASS', 10)
num_prototypes = protos_per_class * num_classes
proto_depth = _i('PC_PROTO_DEPTH', 512 if add_on_layers_type == 'none' else 128)
prototype_shape = (num_prototypes, proto_depth, 1, 1)

last_layer_type = _s('PC_LAST_LAYER', 'single')
debug = _b('PC_DEBUG', False)
hard_sparse = False
use_cap = _b('PC_USE_CAP', True)
ctrl = True
sub_mean = False
ltwo = True

cap_width = _f('PC_CAP_WIDTH', 6.0)
# clst_k is a topk over the prototype dimension, masked to the correct class, so it must
# not exceed the number of prototypes allocated per class or torch.topk raises
# "selected index k out of range". The paper pairs clst_k=10 with 10 prototypes per class.
clst_k = _i('PC_CLST_K', 10)
if clst_k > protos_per_class:
    print(f"WARNING: PC_CLST_K={clst_k} exceeds PC_PROTOS_PER_CLASS={protos_per_class}; "
          f"clamping to {protos_per_class}.")
    clst_k = protos_per_class

sep_cost_filter = 'cutoff'
sep_cost_cutoff = -0.05

spstr = 'hardsparse' if hard_sparse else 'softsparse'
capstr = 'cap' if use_cap else 'nocap'
lstr = 'l2' if ltwo else 'hs'

# ---------------------------------------------------------------- data directories
# Upstream expects the offline-augmented ProtoPNet layout
# (train_cropped_augmented/, test_cropped/, train_cropped/). PC_LAYOUT=imagefolder maps a
# plain train/ + val/ tree onto those three roles instead: train and push share the
# unaugmented train/ directory, and augmentation happens online in the transforms.
data_path = _s('PC_DATA_PATH', '')
layout = _s('PC_LAYOUT', 'imagefolder')

if layout == 'imagefolder':
    _train = os.path.join(data_path, 'train')
    _test = None
    for _c in ('val', 'test', 'valid'):
        if os.path.isdir(os.path.join(data_path, _c)):
            _test = os.path.join(data_path, _c)
            break
    if _test is None:
        _test = os.path.join(data_path, 'val')
    train_dir = _train + os.sep
    test_dir = _test + os.sep
    train_push_dir = _train + os.sep
else:
    train_dir = os.path.join(data_path, 'train_cropped_augmented') + os.sep
    test_dir = os.path.join(data_path, 'test_cropped') + os.sep
    train_push_dir = os.path.join(data_path, 'train_cropped') + os.sep

# Online augmentation for the imagefolder layout. Class-semantics flags, not tuning:
#   PC_VFLIP   only when the imagery has no canonical 'up' (aerial scenes)
#   PC_GRAY    intensity-only modalities such as ultrasound
#   PC_COLOR_JITTER  widen colour jitter when colour varies within a class (cars); leave
#                    off for flowers and birds where colour is class-defining
online_augment = _b('PC_AUGMENT', layout == 'imagefolder')
vflip = _b('PC_VFLIP', False)
grayscale = _b('PC_GRAY', False)
color_jitter = _f('PC_COLOR_JITTER', 0.0)

# ---------------------------------------------------------------- batch sizes
if debug:
    train_batch_size = 5
    test_batch_size = 5
    train_push_batch_size = 5
else:
    train_batch_size = _i('PC_TRAIN_BATCH', 50)
    test_batch_size = _i('PC_TEST_BATCH', 80)
    train_push_batch_size = _i('PC_PUSH_BATCH', 50)

num_workers = _i('PC_NUM_WORKERS', 8)
# Upstream used 4 workers with pin_memory=False. With RandomAffine happening on CPU that
# starves the GPU, which shows up as low utilisation rather than an error.
pin_memory = _b('PC_PIN_MEMORY', True)
persistent_workers = _b('PC_PERSISTENT_WORKERS', True)
prefetch_factor = _i('PC_PREFETCH', 4)
# TF32 matmuls on Ampere+ (A100). PyTorch disables these by default since 1.12; enabling
# them is typically the single largest speedup for a ViT and does not touch loss numerics.
tf32 = _b('PC_TF32', True)

# ---------------------------------------------------------------- optimisation
# A ViT finetunes at a smaller step size than a ResNet, so the features lr defaults lower
# than upstream's 1e-4 when the backbone is a DINO ViT.
_is_vit = base_architecture.startswith('dino')
joint_optimizer_lrs = {'features': _f('PC_LR_FEATURES', 3e-5 if _is_vit else 1e-4),
                       'add_on_layers': _f('PC_LR_ADDON', 3e-3),
                       'prototype_vectors': _f('PC_LR_PROTOS', 3e-3),
                       'last_layer': _f('PC_LR_LAST', 1e-4)}
joint_lr_step_size = _i('PC_LR_STEP', 5)

warm_optimizer_lrs = {'add_on_layers': _f('PC_LR_ADDON', 3e-3),
                      'prototype_vectors': _f('PC_LR_PROTOS', 3e-3),
                      'cap_width': _f('PC_LR_CAP', 5e-4)}

last_layer_optimizer_lr = _f('PC_LR_LAST', 1e-4)

coefs = {
    'crs_ent': _f('PC_C_CRSENT', 1),
    'clst': _f('PC_C_CLST', 0.8),
    'sep': _f('PC_C_SEP', -0.08),
    'l1': _f('PC_C_L1', 1e-4),
    'relu': _f('PC_C_RELU', 1e-3),
    'dist': _f('PC_C_DIST', 1.0),
    'cap': _f('PC_C_CAP', 0.01),
}

if not ctrl:
    experiment_run = 'dyn_ll' + capstr
elif sub_mean:
    experiment_run = 'submean001'
else:
    experiment_run = _s('PC_RUN_NAME', 'arr')

num_train_epochs = _i('PC_EPOCHS', 15)
num_warm_epochs = _i('PC_WARM_EPOCHS', 5)
num_finetune_epochs = _i('PC_FINETUNE_EPOCHS', 20)
# Upstream only saves the finetuned model when accuracy clears 0.70, which silently
# produces no checkpoint on a harder dataset. Default to 0 so a checkpoint is always kept.
save_target_accu = _f('PC_SAVE_TARGET_ACCU', 0.0)

# Visualisation over the full push set is expensive; allow skipping it.
run_visualization = _b('PC_VISUALIZE', True)

if use_cap:
    push_start = float('inf')
    push_epochs = []
else:
    push_start = 10
    push_epochs = [i for i in range(num_train_epochs) if i % 10 == 0]
