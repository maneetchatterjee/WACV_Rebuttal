"""Status of every ProtoConcepts run: phase, progress, checkpoints, best accuracy.

    python3 status.py

Accuracy is read off the checkpoint filenames, which save_model_w_condition writes as
<name><accu:.4f>.pth -- e.g. 19_topk_finetuned0.6630.pth.
"""
import glob
import os
import re
import subprocess
import sys

# Which runs are still alive.
# A DataLoader worker is a fork of this same script, so with PC_NUM_WORKERS=10 and
# persistent_workers=True the three loaders keep ~30 children alive and a naive pgrep
# reports 31 "runs". Keep only processes whose parent is NOT itself a match.
ps = ''
parents = []
try:
    raw = subprocess.run(['ps', '-eo', 'pid,ppid,args'], capture_output=True, text=True).stdout
    matched = {}
    for line in raw.splitlines():
        if 'main_ctrl_caps' in line and 'ps -eo' not in line:
            parts = line.split(None, 2)
            if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
                matched[int(parts[0])] = (int(parts[1]), parts[2])
    parents = [(pid, cmd) for pid, (ppid, cmd) in sorted(matched.items()) if ppid not in matched]
    ps = '\n'.join(f'{pid} {cmd}' for pid, cmd in parents)
    n_workers = len(matched) - len(parents)
except Exception:
    try:
        ps = subprocess.run(['pgrep', '-af', 'main_ctrl_caps'],
                            capture_output=True, text=True).stdout
    except Exception:
        ps = ''
    n_workers = 0

runs = sorted(glob.glob('saved_models/*/*/*/'))
if not runs:
    sys.exit("No runs found under saved_models/*/*/*/")

hdr = (f"{'dataset':<10} {'arch':<14} {'phase':<10} {'progress':>10} {'ckpts':>6} "
       f"{'best nofinetune':>16} {'best finetuned':>15} {'alive':>6}")
print(hdr)
print('-' * len(hdr))

for run in runs:
    parts = run.rstrip(os.sep).split(os.sep)
    ds, arch = parts[1], parts[2]

    cfg = {}
    cfgp = os.path.join(run, 'run_config.json')
    if os.path.exists(cfgp):
        try:
            import json
            cfg = json.load(open(cfgp))
        except Exception:
            cfg = {}
    tgt_train = cfg.get('num_train_epochs')
    tgt_ft = cfg.get('num_finetune_epochs')
    tgt_warm = cfg.get('num_warm_epochs', 15)

    log = os.path.join(run, 'train.log')
    phase, progress = 'unknown', '-'
    if os.path.exists(log):
        txt = open(log, errors='ignore').read()
        epochs = re.findall(r'epoch:\s*(\d+)', txt)
        iters = re.findall(r'iteration:\s*(\d+)', txt)
        if iters:
            last = int(iters[-1])
            done = tgt_ft is not None and last >= tgt_ft - 1
            phase = 'DONE' if done else 'finetune'
            progress = f"ft {last+1}/{tgt_ft}" if tgt_ft else f"iter {last}"
        elif epochs:
            last = int(epochs[-1])
            phase = 'warm' if last < tgt_warm else 'joint'
            progress = f"{last+1}/{tgt_train}" if tgt_train else f"epoch {last}"

    cks = glob.glob(os.path.join(run, '*.pth'))
    n_corrupt = sum(1 for c in cks if os.path.isfile(c) and os.path.getsize(c) < (1 << 20))

    MIN_VALID = 1 << 20  # ignore checkpoints a full disk truncated; their filename still
                         # carries an accuracy and would otherwise be reported as a result

    def best(pattern):
        vals = []
        for c in cks:
            b = os.path.basename(c)
            try:
                if os.path.getsize(c) < MIN_VALID:
                    continue
            except OSError:
                continue
            if pattern in b:
                m = re.search(r'([01]\.\d{4})\.pth$', b)
                if m:
                    vals.append(float(m.group(1)))
        return f"{max(vals)*100:.2f}%" if vals else '-'

    alive = 'YES' if f'/{ds}/' in ps or f'PC_DATASET={ds}' in ps else ''
    # pgrep shows only the python command line, not env, so fall back to a single-run guess
    if not alive and ps.strip() and len(runs) == 1:
        alive = 'YES'

    ck_col = f"{len(cks)}" + (f"({n_corrupt}!)" if n_corrupt else "")
    print(f"{ds:<10} {arch:<14} {phase:<10} {progress:>10} {ck_col:>6} "
          f"{best('nofinetune'):>16} {best('finetuned'):>15} {alive:>6}")

print()
n_alive = len([l for l in ps.strip().split('\n') if l.strip()])
extra = f" (+{n_workers} DataLoader workers)" if n_workers else ""
print(f"{n_alive} training run(s) currently active{extra}.")
if ps.strip():
    for line in ps.strip().split('\n'):
        print('   ', line)
print("\nNote: 'alive' cannot be attributed per-dataset from pgrep (the dataset comes from")
print("the environment, not the command line). Use the process list above plus each run's")
print("log mtime to tell which is which:")
print("   ls -l --time-style=+%H:%M saved_models/*/*/*/train.log")
