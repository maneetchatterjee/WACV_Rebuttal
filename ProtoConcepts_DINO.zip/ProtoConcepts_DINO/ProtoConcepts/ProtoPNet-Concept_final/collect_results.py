import argparse
import csv
import glob
import os
import re

DATASET_ORDER = ['cub', 'car', 'flower', 'aid', 'gbcu']
DATASET_LABEL = {'cub': 'CUB-200-2011', 'car': 'Stanford Cars', 'flower': 'Oxford Flowers-102',
                 'aid': 'AID', 'gbcu': 'GBCU'}


# ---------------------------------------------------------------- PIP-Net
def parse_pipnet(runs_dir):
    out = {}
    for run in sorted(glob.glob(os.path.join(runs_dir, 'pipnet_*'))):
        name = os.path.basename(run)
        m = re.match(r'pipnet_([a-z0-9]+)_', name)
        if not m:
            continue
        ds = m.group(1)
        csvp = os.path.join(run, 'log_epoch_overview.csv')
        if not os.path.exists(csvp):
            continue
        with open(csvp) as f:
            rows = list(csv.DictReader(f))

        def num(r, k):
            v = r.get(k)
            if v in (None, '', 'n.a.'):
                return None
            try:
                return float(v)
            except ValueError:
                return None

        evaluated = [r for r in rows if num(r, 'test_top1_acc') is not None]
        if not evaluated:
            continue
        final = evaluated[-1]
        best = max(evaluated, key=lambda r: num(r, 'test_top1_acc'))
        # mean_train_acc is logged on the same row as the eval
        train_rows = [r for r in rows if num(r, 'mean_train_acc') is not None]
        out[ds] = {
            'run': name,
            'test_top1': num(final, 'test_top1_acc'),
            'test_top5': num(final, 'test_top5_acc'),
            'best_top1': num(best, 'test_top1_acc'),
            'train_acc': num(train_rows[-1], 'mean_train_acc') if train_rows else None,
            'protos': num(final, 'num_nonzero_prototypes'),
            'epochs': len(rows),
        }
    return out


# ---------------------------------------------------------------- ProtoConcepts
_ACCU = re.compile(r'^\s*accu:\s+([\d.]+)\s*%')
_HDR = re.compile(r'^\s*(epoch|iteration):\s*(\d+)')


def parse_protoconcepts_log(path):
    """Return list of (kind, index, train_accu, test_accu) in file order."""
    blocks = []
    kind = idx = None
    section = None
    cur = {}
    for line in open(path, errors='ignore'):
        h = _HDR.match(line)
        if h:
            if kind is not None:
                blocks.append((kind, idx, cur.get('train'), cur.get('test')))
            kind, idx = h.group(1), int(h.group(2))
            section, cur = None, {}
            continue
        stripped = line.strip()
        if stripped in ('train', 'test'):
            section = stripped
            continue
        a = _ACCU.match(line)
        if a and section:
            # first accu after the section marker is the one we want
            cur.setdefault(section, float(a.group(1)) / 100.0)
    if kind is not None:
        blocks.append((kind, idx, cur.get('train'), cur.get('test')))
    return blocks


def parse_protoconcepts(models_dir):
    out = {}
    for run in sorted(glob.glob(os.path.join(models_dir, '*', '*', '*') + os.sep)):
        parts = run.rstrip(os.sep).split(os.sep)
        ds, arch = parts[-3], parts[-2]
        log = os.path.join(run, 'train.log')
        if not os.path.exists(log):
            continue
        blocks = parse_protoconcepts_log(log)
        pre = [b for b in blocks if b[0] == 'epoch']
        post = [b for b in blocks if b[0] == 'iteration']

        def pick(bs):
            ev = [b for b in bs if b[3] is not None]
            if not ev:
                return None, None, None
            final = ev[-1]
            best = max(ev, key=lambda b: b[3])
            return final[2], final[3], best[3]

        pre_tr, pre_te, pre_best = pick(pre)
        post_tr, post_te, post_best = pick(post)

        vis = None
        vp = os.path.join(run, 'img', 'vis_count.npy')
        if os.path.exists(vp):
            try:
                import numpy as np
                v = np.load(vp)
                vis = (int((v > 0).sum()), int(len(v)))
            except Exception:
                pass

        out[ds] = {'run': f"{ds}/{arch}", 'arch': arch,
                   'pre_train': pre_tr, 'pre_test': pre_te, 'pre_best': pre_best,
                   'post_train': post_tr, 'post_test': post_te, 'post_best': post_best,
                   'epochs': len(pre), 'finetune_iters': len(post), 'vis': vis}
    return out


def pct(v):
    return '--' if v is None else f"{v*100:.2f}"


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--pipnet-runs', default='PIPNet_DINO_CUB/runs')
    p.add_argument('--protoconcepts-models',
                   default='ProtoConcepts/ProtoPNet-Concept_final/saved_models')
    p.add_argument('--out-prefix', default='results_summary')
    a = p.parse_args()

    pip = parse_pipnet(a.pipnet_runs)
    pc = parse_protoconcepts(a.protoconcepts_models)
    datasets = [d for d in DATASET_ORDER if d in pip or d in pc]
    datasets += sorted(set(list(pip) + list(pc)) - set(DATASET_ORDER))

    # ------------------------------------------------------------------ console
    print("\nPIP-Net (DINO ViT-B/16)")
    h = f"{'dataset':<20} {'train acc':>10} {'test top1':>10} {'test top5':>10} {'best top1':>10} {'protos':>7} {'epochs':>7}"
    print(h); print('-' * len(h))
    for d in datasets:
        r = pip.get(d)
        if not r:
            print(f"{DATASET_LABEL.get(d,d):<20} {'-- not run --':>10}"); continue
        print(f"{DATASET_LABEL.get(d,d):<20} {pct(r['train_acc']):>10} {pct(r['test_top1']):>10} "
              f"{pct(r['test_top5']):>10} {pct(r['best_top1']):>10} "
              f"{('%d' % r['protos']) if r['protos'] else '--':>7} {r['epochs']:>7}")

    print("\nProtoConcepts (DINO ViT-B/16)   pre-mask = before mask(vis_count); post-mask = after, last layer retrained")
    h2 = (f"{'dataset':<20} {'pre train':>10} {'pre test':>10} {'post train':>11} "
          f"{'post test':>10} {'visualisable':>14} {'epochs':>7}")
    print(h2); print('-' * len(h2))
    for d in datasets:
        r = pc.get(d)
        if not r:
            print(f"{DATASET_LABEL.get(d,d):<20} {'-- not run --':>10}"); continue
        vis = f"{r['vis'][0]}/{r['vis'][1]}" if r['vis'] else '--'
        print(f"{DATASET_LABEL.get(d,d):<20} {pct(r['pre_train']):>10} {pct(r['pre_test']):>10} "
              f"{pct(r['post_train']):>11} {pct(r['post_test']):>10} {vis:>14} {r['epochs']:>7}")

    # ------------------------------------------------------------------ csv
    csv_path = a.out_prefix + '.csv'
    with open(csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['dataset', 'method', 'backbone', 'train_acc', 'test_top1', 'test_top5',
                    'best_test_top1', 'prototypes_used', 'visualisable_prototypes',
                    'epochs', 'notes'])
        for d in datasets:
            if d in pip:
                r = pip[d]
                w.writerow([DATASET_LABEL.get(d, d), 'PIP-Net', 'DINO ViT-B/16',
                            r['train_acc'], r['test_top1'], r['test_top5'], r['best_top1'],
                            int(r['protos']) if r['protos'] else '', '', r['epochs'], ''])
            if d in pc:
                r = pc[d]
                w.writerow([DATASET_LABEL.get(d, d), 'ProtoConcepts (pre-mask)', 'DINO ViT-B/16',
                            r['pre_train'], r['pre_test'], '', r['pre_best'], '',
                            r['vis'][1] if r['vis'] else '', r['epochs'], ''])
                w.writerow([DATASET_LABEL.get(d, d), 'ProtoConcepts (post-mask)', 'DINO ViT-B/16',
                            r['post_train'], r['post_test'], '', r['post_best'], '',
                            r['vis'][0] if r['vis'] else '', r['finetune_iters'],
                            'last layer retrained on visualisable prototypes'])
    print(f"\nwrote {csv_path}")

    # ------------------------------------------------------------------ latex
    tex_path = a.out_prefix + '.tex'
    with open(tex_path, 'w') as f:
        f.write("% Quantitative comparison, all datasets, identical DINO ViT-B/16 backbone.\n")
        f.write("% ProtoConcepts post-mask = after prototypes that cannot be visualised are\n")
        f.write("% disabled and the last layer is retrained.\n")
        f.write("\\begin{tabular}{l" + "r" * (len(datasets) * 1) + "}\n\\toprule\n")
        f.write("Method & " + " & ".join(DATASET_LABEL.get(d, d) for d in datasets) + " \\\\\n")
        f.write("\\midrule\n")
        row = ["PIP-Net (test)"]
        for d in datasets:
            row.append(pct(pip[d]['test_top1']) if d in pip else '--')
        f.write(" & ".join(row) + " \\\\\n")
        row = ["PIP-Net (train)"]
        for d in datasets:
            row.append(pct(pip[d]['train_acc']) if d in pip else '--')
        f.write(" & ".join(row) + " \\\\\n")
        f.write("\\midrule\n")
        for label, key in (("ProtoConcepts pre-mask (test)", 'pre_test'),
                           ("ProtoConcepts post-mask (test)", 'post_test'),
                           ("ProtoConcepts post-mask (train)", 'post_train')):
            row = [label]
            for d in datasets:
                row.append(pct(pc[d][key]) if d in pc else '--')
            f.write(" & ".join(row) + " \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n")
    print(f"wrote {tex_path}")
    print("\nAll numbers are top-1 accuracy in percent. '--' means the run is missing.")


if __name__ == '__main__':
    main()
