# TesNet with a DINO ViT backbone

[TesNet](https://github.com/JackeyWang96/TesNet) (Wang et al., ICCV 2021 — *Interpretable
Image Recognition by Constructing Transparent Embedding Space*) with the CNN backbone
swapped for a self-supervised **DINO ViT**, and dataset paths made configurable so the same
code runs CUB / Cars / Flowers / AID / GBCU.

Cloned from `JackeyWang96/TesNet` at master. Changes are deliberately minimal — see §1.

---

## 1. Every change from upstream

### Backbone (what you asked for)

| file | change |
|---|---|
| `models/dino_features.py` | **New.** `DINOViTFeatures` folds ViT patch tokens back onto their grid to emit `(B, C, H, W)`, and implements **`conv_info()`** as a single conv of kernel = stride = patch size — `construct_TesNet` calls it for receptive-field maths. Six backbones registered. |
| `model.py` | 3 edits: import the DINO factories; add them to `base_architecture_to_features`; add a `DINO` branch to the channel detection, which reads `features.out_channels`. Upstream's "last `nn.Conv2d`" heuristic would pick `patch_embed.proj` — a ViT's *first* conv. |

**Verified:** `dino_vitb16` gives `rf_info = [14, 16, 16, 8.0]` at 224px — a 14×14 grid where
cell *n* covers pixels `[16n, 16n+16)`. `conv_features` comes out `(B, 64, 14, 14)`.

Note `models/dino_features.py` must keep that exact name: `main.py:48` copies
`models/<arch_type>_features.py` where `arch_type = re.match('^[a-z]*', arch)`, which is
`dino` for `dino_vitb16`.

### Dataset paths (what you asked for)

| file | change |
|---|---|
| `settings_CUB.py` | Every value now reads an environment variable **with the upstream value as its default**. Set nothing and you get upstream TesNet exactly. Adds `TN_LAYOUT=imagefolder` to map a plain `train/` + `val/` tree onto upstream's three roles. |
| `main.py` | One line: `if dataset_name == "CUB":` → `if dataset_name:`. Upstream raised for any other name, making a second dataset impossible without editing the file. `-dataset` now only tags the output directory. |

### Storage (what you asked me to check) — two changes

| file | change |
|---|---|
| `util/save.py` | Keeps only the **best** checkpoint per family; skips the write entirely when it cannot improve; writes atomically via a temp file + rename; survives a full disk instead of killing the run. |
| `main.py` | `target_accu=0.70` → `save_target_accu` (from `TN_SAVE_TARGET_ACCU`) at all four save sites. |

**Why this was necessary.** Upstream's `util/save.py` is byte-identical to ProtoPNet's — a
whole pickled model (~350 MB for ViT-B/16 with 2000 concepts) every time accuracy clears
`target_accu`, from four call sites in `main.py`:

- `<epoch>nopush<accu>.pth` — every epoch
- `<epoch>push<accu>.pth` — every push epoch
- `<epoch>_<i>push<accu>.pth` — every last-layer finetune iteration (20 per push)

Measured on a 2-epoch test run: **21 checkpoints**. Extrapolated to a real 20-epoch run
with two push epochs: **well over 20 GB per dataset**. And at `target_accu=0.70`, a dataset
that never reaches 70% (GBCU) trains fully and saves **nothing at all**.

`util/save.py` collapses the family by removing all digits from the name, so
`1_0push` … `1_19push` are one family (`_push`) rather than twenty. Verified: the same
2-epoch run now leaves **3** checkpoints — one each for `nopush`, `push`, `_push`.

`push.py` is *not* a second problem: it writes one image set per prototype per push epoch,
bounded at ~2.6 GB with the default `push_epochs = [0, 10]`.

### Nothing else changed

The objective is untouched: all six loss coefficients (`crs_ent 1, clst 0.8, sep -0.08,
l1 1e-4, orth 1e-4, sub_sep -1e-7`), `prototype_shape` depth 64, `add_on_layers_type
regular`, epochs 20/5, `push_start 10`, and the orthogonality / subspace-separation terms
that make TesNet TesNet. The only defaults that differ from the file upstream ships are the
per-dataset ones that *must* (see §4).

---

## 2. Setup

```bash
tar xzf TesNet_DINO.tgz && cd TesNet
pip install torch torchvision timm opencv-python numpy
python3 check_setup.py --data_path /home/paul/Paul/DATASETS/CUB --dataset cub
```

## 3. Running

```bash
DATASET=cub    GPU=0 nohup bash run_tesnet_dino.sh > tn_cub.log 2>&1 &
DATASET=car    GPU=1 nohup bash run_tesnet_dino.sh > tn_car.log 2>&1 &
DATASET=flower GPU=2 nohup bash run_tesnet_dino.sh > tn_flower.log 2>&1 &
DATASET=aid    GPU=3 nohup bash run_tesnet_dino.sh > tn_aid.log 2>&1 &
DATASET=gbcu   GPU=0 nohup bash run_tesnet_dino.sh > tn_gbcu.log 2>&1 &
```

Checkpoints: `saved_models/<dataset>/<arch>/<times>/`.

> **`main.py:41-43` does `shutil.rmtree(model_dir)` at startup.** Relaunching with the same
> `DATASET`/`ARCH`/`TIMES` **deletes the previous run outright.** Pass a different `TIMES=`
> to keep an earlier run. This is upstream behaviour, not something introduced here.

## 4. Per-dataset values that are forced

`model.py` asserts `num_prototypes % num_classes == 0`, so upstream's hardcoded 2000 is
valid only for 200 classes. `run_tesnet_dino.sh` **detects the class count** from the
`train/` tree and computes `TN_PROTOS_PER_CLASS × num_classes`, preserving upstream's
10-per-class ratio:

| dataset | classes | basis concepts |
|---|---|---|
| CUB | 200 | 2000 (numerically identical to upstream) |
| Cars | 196 | 1960 |
| Flowers | 102 | 1020 |
| AID | 30 | 300 |
| GBCU | 3 | 30 |

Two other defaults differ, and both are revertible:

- **`TN_LR_FEATURES` 1e-4 → 3e-5** when the backbone is a DINO ViT, on the convention that
  ViTs finetune at a smaller step than a VGG. `TN_LR_FEATURES=1e-4` restores upstream.
- **`TN_SAVE_TARGET_ACCU` 0.70 → 0.0** in the runner, so a hard dataset still yields a
  checkpoint. Costs ~3 files, not one per epoch.

Also note upstream reads `train_cropped_augmented/` — offline-augmented with Augmentor,
roughly 30× the images, from bbox crops. Your `train/` folders are plain and uncropped, so
each epoch is ~30× smaller in weight updates. Upstream's 20 epochs assumes the augmented
directory; consider `TN_EPOCHS` higher if results look undertrained. `main.py` applies no
online augmentation and I have not added any, since that would be a change beyond backbone
and paths — flag it if you want it.

## 5. Useful variables

| var | default | meaning |
|---|---|---|
| `TN_ARCH` | `dino_vitb16` (via runner) | backbone |
| `TN_IMG_SIZE` | 224 | must be a multiple of the patch size |
| `TN_PROTOS_PER_CLASS` | 10 | × num_classes = basis concepts |
| `TN_EPOCHS` / `TN_WARM_EPOCHS` | 20 / 5 | upstream values |
| `TN_PUSH_START` / `TN_PUSH_EVERY` | 10 / 10 | push schedule |
| `TN_TRAIN_BATCH` | 48 (runner; upstream 80) | lower first on CUDA OOM |
| `TN_SAVE_TARGET_ACCU` | 0.0 (runner; upstream 0.70) | save threshold |
| `PC_SAVE_BEST_ONLY` | 1 | set 0 to restore save-every-epoch |

## 6. What is and is not verified

Verified on this port: `construct_TesNet` builds with `dino_vitb16` / `dino_vits16` /
`dinov2_vitb14`; correct latent grid and receptive-field info; `main.py` run to completion
(warm → joint → push → last-layer finetune) producing checkpoints and prototype images; the
checkpoint family collapse (21 files → 3); and `settings_CUB.py` resolving to upstream's
exact values when no environment variables are set.

Not verified: accuracy on any dataset, and GPU memory at `TN_TRAIN_BATCH=48`. TesNet pushes
prototypes onto real training patches (unlike ProtoConcepts with `use_cap=True`), so its
prototypes are genuine training patches — a closer comparison to PIP-Net.
