"""Preflight check for TesNet + DINO, before committing to a long run.

    python3 check_setup.py --data_path /home/paul/Paul/DATASETS/CUB --dataset cub
"""
import argparse, os, sys

OK, BAD = "  [ok] ", "  [!!] "
failures = []


def check(label, fn):
    try:
        d = fn()
        print(OK + label + (": " + d if d else ""))
    except Exception as e:
        print(BAD + label + ": " + str(e))
        failures.append(label)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data_path', required=True)
    p.add_argument('--dataset', default='cub')
    p.add_argument('--arch', default='dino_vitb16')
    p.add_argument('--img_size', type=int, default=224)
    p.add_argument('--protos_per_class', type=int, default=10)
    p.add_argument('--train_batch', type=int, default=48)
    p.add_argument('--skip_weights', action='store_true')
    a = p.parse_args()

    print("\n== packages ==")
    check("torch", lambda: __import__('torch').__version__)

    def _timm():
        import timm
        v = tuple(int(x) for x in timm.__version__.split('.')[:2])
        if v < (0, 9):
            raise RuntimeError(f"timm {timm.__version__} too old, need >= 0.9.8")
        return timm.__version__
    check("timm", _timm)
    for m in ('torchvision', 'cv2', 'numpy'):
        check(m, lambda mm=m: getattr(__import__(mm), '__version__', ''))

    print("\n== gpu ==")
    def _gpu():
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("no CUDA device visible; TesNet calls .cuda() unconditionally")
        free, total = torch.cuda.mem_get_info(0)
        return (f"{torch.cuda.device_count()} device(s), "
                f"{free/2**30:.1f}/{total/2**30:.1f} GiB free on cuda:0")
    check("cuda", _gpu)

    print("\n== data ==")
    info = {}
    def _data():
        root = a.data_path
        train = os.path.join(root, 'train')
        test = None
        for c in ('val', 'test', 'valid'):
            if os.path.isdir(os.path.join(root, c)):
                test = os.path.join(root, c); break
        if not os.path.isdir(train):
            raise FileNotFoundError(f"missing {train}")
        if test is None:
            raise FileNotFoundError(f"no val/ test/ valid/ under {root}")
        lines = []
        for label, d in (('train', train), ('test', test)):
            classes = sorted(e for e in os.listdir(d) if os.path.isdir(os.path.join(d, e)))
            per = {c: len([f for f in os.listdir(os.path.join(d, c))
                           if os.path.isfile(os.path.join(d, c, f))]) for c in classes}
            info[label] = (len(classes), sum(per.values()), per)
            lines.append(f"\n      {label:6s} {len(classes):4d} classes, {sum(per.values()):6d} images  {d}")
        return "".join(lines)
    check(f"dataset '{a.dataset}'", _data)

    if 'train' in info:
        ncls, ntrain, per = info['train']
        nproto = a.protos_per_class * ncls
        print("\n== basis concepts ==")
        def _proto():
            if nproto % ncls:
                raise RuntimeError("num_prototypes must divide evenly by num_classes")
            return (f"{nproto} = {a.protos_per_class} x {ncls} classes, depth 64 "
                    f"(model.py asserts the divisibility)")
        check("allocation", _proto)
        if per:
            lo, hi = min(per.values()), max(per.values())
            print(f"  [--] imbalance ratio: {hi/max(lo,1):.1f}x (largest {hi} / smallest {lo})")
        print(f"  [--] at train_batch {a.train_batch}: {ntrain // a.train_batch} iters/epoch")
        if 'test' in info and info['test'][0] != ncls:
            print(f"  {BAD.strip()} train has {ncls} classes but test has {info['test'][0]}")
            failures.append('class count mismatch')

    print("\n== backbone ==")
    def _w():
        if a.skip_weights:
            return "skipped"
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from models.dino_features import is_dino_net
        import model as M
        if not is_dino_net(a.arch):
            return f"{a.arch} is not a DINO backbone"
        f = M.base_architecture_to_features[a.arch](pretrained=True, img_size=a.img_size)
        if a.img_size % f.patch_size:
            raise ValueError(f"img_size {a.img_size} not a multiple of patch {f.patch_size}")
        g = a.img_size // f.patch_size
        return f"{a.arch}: {f.out_channels} channels, {g}x{g} latent grid"
    check("DINO weights", _w)

    print()
    if failures:
        print(f"{len(failures)} check(s) failed: {failures}")
        sys.exit(1)
    print(f"All checks passed. Launch with:  DATASET={a.dataset} bash run_tesnet_dino.sh")


if __name__ == '__main__':
    main()
