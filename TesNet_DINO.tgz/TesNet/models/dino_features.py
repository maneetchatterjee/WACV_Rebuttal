"""DINO / DINOv2 Vision Transformer backbones for ProtoConcepts (ProtoPNet-Concept).

ProtoPNet-family models need three things from a backbone that a timm ViT does not
provide out of the box:

  1. a 4D feature map (B, C, H, W) -- the prototype layer does an L2 "convolution" over
     spatial positions, so tokens must be folded back onto their grid;
  2. `conv_info()` returning (kernel_sizes, strides, paddings), used by
     compute_proto_layer_rf_info_v2 to map a latent position back to image pixels;
  3. a channel count discoverable by the model constructor.

For (2) a ViT-B/16 is exactly equivalent to a single conv with kernel 16, stride 16,
padding 0: at 224px that yields a 14x14 grid whose cell n covers pixels [16n, 16n+16).
That is the *nominal* patch. A ViT's true receptive field is the whole image because
attention is global, but the patch is the right unit for prototype localisation -- the
same choice the DINO attention-map literature makes.

Grid sizes at img_size 224:
    dino_vitb16 / dino_vits16      patch 16 -> 14x14   (768 / 384 channels)
    dino_vitb8  / dino_vits8       patch  8 -> 28x28   (768 / 384 channels)
    dinov2_vitb14 / dinov2_vits14  patch 14 -> 16x16   (768 / 384 channels)
"""

import math

import torch
import torch.nn as nn

try:
    import timm
except ImportError as exc:  # pragma: no cover
    raise ImportError("The DINO backbones need timm: pip install 'timm>=0.9.8'") from exc


class DINOViTFeatures(nn.Module):
    """Wraps a timm ViT so it behaves like ProtoPNet's CNN feature extractors."""

    def __init__(self, model_name, pretrained=True, img_size=224, drop_path_rate=0.0,
                 grad_checkpointing=False, ckpt_path=''):
        super().__init__()
        create_kwargs = dict(pretrained=pretrained, num_classes=0, img_size=img_size,
                             drop_path_rate=drop_path_rate)
        try:
            self.vit = timm.create_model(model_name, dynamic_img_size=True, **create_kwargs)
        except TypeError:
            print("timm without dynamic_img_size; input size is fixed.", flush=True)
            self.vit = timm.create_model(model_name, **create_kwargs)

        if ckpt_path:
            state = torch.load(ckpt_path, map_location='cpu')
            for key in ('model', 'state_dict', 'teacher', 'student'):
                if isinstance(state, dict) and key in state:
                    state = state[key]
                    break
            state = {k.replace('module.', '').replace('backbone.', ''): v for k, v in state.items()}
            missing, unexpected = self.vit.load_state_dict(state, strict=False)
            print(f"Loaded DINO weights from {ckpt_path} "
                  f"(missing {len(missing)}, unexpected {len(unexpected)})", flush=True)

        if grad_checkpointing:
            self.vit.set_grad_checkpointing(True)
            print("Gradient checkpointing enabled on the ViT backbone.", flush=True)

        self.model_name = model_name
        self.out_channels = self.vit.embed_dim
        self.patch_size = self.vit.patch_embed.patch_size[0]
        self.num_prefix_tokens = getattr(self.vit, 'num_prefix_tokens', 1)
        self.depth = len(self.vit.blocks)

        print(f"DINO backbone {model_name}: {self.depth} blocks, {self.out_channels} channels, "
              f"patch {self.patch_size}, grid {img_size // self.patch_size}x"
              f"{img_size // self.patch_size} at {img_size}px", flush=True)

    def conv_info(self):
        """Receptive-field description: one conv of kernel=stride=patch_size, no padding."""
        return [self.patch_size], [self.patch_size], [0]

    def forward(self, x):
        tokens = self.vit.forward_features(x)          # (B, num_prefix + H*W, C)
        tokens = tokens[:, self.num_prefix_tokens:]    # drop CLS (+ register) tokens
        b, n, c = tokens.shape
        h = int(round(math.sqrt(n)))
        if h * h != n:
            raise ValueError(
                f"Expected a square token grid, got {n} tokens. Keep img_size square and "
                f"divisible by the patch size ({self.patch_size}).")
        # timm lays patch tokens out row-major, so this restores the (H, W) grid.
        return tokens.transpose(1, 2).reshape(b, c, h, h)

    def __repr__(self):
        # The model constructor branches on str(features).upper(); this keeps the DINO
        # backbones identifiable and stops them matching RES/VGG/DENSE by accident.
        return f"DINO_{self.model_name}"


def _make(model_name):
    def _factory(pretrained=True, **kwargs):
        return DINOViTFeatures(model_name, pretrained=pretrained, **kwargs)
    return _factory


dino_vitb16_features = _make('vit_base_patch16_224.dino')
dino_vits16_features = _make('vit_small_patch16_224.dino')
dino_vitb8_features = _make('vit_base_patch8_224.dino')
dino_vits8_features = _make('vit_small_patch8_224.dino')
dinov2_vitb14_features = _make('vit_base_patch14_dinov2.lvd142m')
dinov2_vits14_features = _make('vit_small_patch14_dinov2.lvd142m')

DINO_NETS = ('dino_vitb16', 'dino_vits16', 'dino_vitb8', 'dino_vits8',
             'dinov2_vitb14', 'dinov2_vits14')


def is_dino_net(name):
    return name in DINO_NETS
