"""TesNet settings, driven by environment variables.

Upstream hardcodes every value here and main.py accepts only -dataset CUB, so running five
datasets means editing this file between runs. Every setting below now reads an environment
variable with the ORIGINAL value as its default: set nothing and you get upstream TesNet
exactly. Only the values you export change.

Required per dataset:
    TN_DATA_PATH    dataset root holding train/ and val/ (or test/)
    TN_NUM_CLASSES  number of classes

Key constraint: num_prototypes must divide evenly by num_classes, because TesNet allocates
an equal number of prototypes per class (model.py asserts it). TN_PROTOS_PER_CLASS
(default 10, matching upstream's 2000/200 for CUB) is multiplied by num_classes.
"""
import os


def _s(n, d):
    return os.environ.get(n, d)


def _i(n, d):
    return int(os.environ.get(n, d))


def _f(n, d):
    return float(os.environ.get(n, d))


def _b(n, d):
    v = os.environ.get(n)
    return d if v is None else v.strip().lower() in ('1', 'true', 'yes', 'on')


img_size = _i('TN_IMG_SIZE', 224)
num_classes = _i('TN_NUM_CLASSES', 200)

# upstream: prototype_shape = (2000, 64, 1, 1) -- note depth 64, not ProtoPNet's 128
protos_per_class = _i('TN_PROTOS_PER_CLASS', 10)
proto_depth = _i('TN_PROTO_DEPTH', 64)
prototype_shape = (protos_per_class * num_classes, proto_depth, 1, 1)

prototype_activation_function = _s('TN_PROTO_ACT', 'log')
add_on_layers_type = _s('TN_ADD_ON', 'regular')

experiment_run = _s('TN_RUN_NAME', '001')
base_architecture = _s('TN_ARCH', 'vgg19')

# ---------------------------------------------------------------- data directories
# Upstream expects the offline-augmented ProtoPNet layout (train_cropped_augmented/,
# test_cropped/, train_cropped/). TN_LAYOUT=imagefolder maps a plain train/ + val/ tree
# onto those three roles instead: train and push share the unaugmented train/ directory.
data_path = _s('TN_DATA_PATH', '')
layout = _s('TN_LAYOUT', 'imagefolder')

if layout == 'imagefolder':
    _train = os.path.join(data_path, 'train')
    _test = None
    for _c in ('val', 'test', 'valid'):
        if os.path.isdir(os.path.join(data_path, _c)):
            _test = os.path.join(data_path, _c)
            break
    if _test is None:
        _test = os.path.join(data_path, 'val')
    train_dir = _train + os.sep
    test_dir = _test + os.sep
    train_push_dir = _train + os.sep
else:
    train_dir = data_path + 'train_cropped_augmented/'
    test_dir = data_path + 'test_cropped/'
    train_push_dir = data_path + 'train_cropped/'

train_batch_size = _i('TN_TRAIN_BATCH', 80)
test_batch_size = _i('TN_TEST_BATCH', 100)
train_push_batch_size = _i('TN_PUSH_BATCH', 75)

# A ViT finetunes at a smaller step size than a VGG/ResNet, so the features lr defaults
# lower than upstream's 1e-4 when the backbone is a DINO ViT. Override with TN_LR_FEATURES.
_is_vit = base_architecture.startswith('dino')
joint_optimizer_lrs = {'features': _f('TN_LR_FEATURES', 3e-5 if _is_vit else 1e-4),
                       'add_on_layers': _f('TN_LR_ADDON', 3e-3),
                       'prototype_vectors': _f('TN_LR_PROTOS', 3e-3)}
joint_lr_step_size = _i('TN_LR_STEP', 5)

warm_optimizer_lrs = {'add_on_layers': _f('TN_LR_ADDON', 3e-3),
                      'prototype_vectors': _f('TN_LR_PROTOS', 3e-3)}

last_layer_optimizer_lr = _f('TN_LR_LAST', 1e-4)

coefs = {
    'crs_ent': _f('TN_C_CRSENT', 1),
    'clst': _f('TN_C_CLST', 0.8),
    'sep': _f('TN_C_SEP', -0.08),
    'l1': _f('TN_C_L1', 1e-4),
    'orth': _f('TN_C_ORTH', 1e-4),
    'sub_sep': _f('TN_C_SUBSEP', -1e-7),
}

num_train_epochs = _i('TN_EPOCHS', 20)
num_warm_epochs = _i('TN_WARM_EPOCHS', 5)

push_start = _i('TN_PUSH_START', 10)
_push_every = _i('TN_PUSH_EVERY', 10)
push_epochs = [i for i in range(num_train_epochs) if i % _push_every == 0]

# Upstream saves a whole pickled model (~350 MB) at three call sites in main.py whenever
# accuracy clears this. At 0.70 that is one file per epoch on an easy dataset and NOTHING
# at all on a hard one. See util/save.py, which keeps only the best file per family.
save_target_accu = _f('TN_SAVE_TARGET_ACCU', 0.70)
