"""Has each TesNet run finished, and if not, how far along is it?

    python3 status_tesnet.py

TesNet writes no completion marker -- main.py just calls logclose() -- so this combines
three signals:

  1. train.log      the last "epoch: N" (and "iteration: i" inside a push epoch)
  2. runs_meta/*.json  the target epoch count, written by run_tesnet_dino.sh
  3. tn_*.log       the runner's "TESNET_RUN_COMPLETE" line, which is definitive
  4. ps             whether a training process is still alive

A run is DONE when the last epoch equals num_train_epochs - 1 and no process is alive.
"""
import glob
import json
import os
import re
import subprocess

MIN_VALID = 1 << 20   # ignore checkpoints a full disk truncated


def parents_alive():
    """Live training processes, excluding DataLoader worker forks of the same script."""
    try:
        raw = subprocess.run(['ps', '-eo', 'pid,ppid,args'],
                             capture_output=True, text=True).stdout
    except Exception:
        return [], 0
    matched = {}
    for line in raw.splitlines():
        if 'main.py' in line and '-arch' in line and 'ps -eo' not in line:
            p = line.split(None, 2)
            if len(p) == 3 and p[0].isdigit() and p[1].isdigit():
                matched[int(p[0])] = (int(p[1]), p[2])
    par = [(pid, cmd) for pid, (ppid, cmd) in sorted(matched.items()) if ppid not in matched]
    return par, len(matched) - len(par)


def runner_said_complete(ds, arch, times):
    for log in glob.glob('tn_*.log') + glob.glob('*.log'):
        try:
            txt = open(log, errors='ignore').read()
        except OSError:
            continue
        if f'TESNET_RUN_COMPLETE {ds} {arch} {times}' in txt:
            return os.path.basename(log)
    return None


def main():
    runs = sorted(glob.glob(os.path.join('saved_models', '*', '*', '*') + os.sep))
    if not runs:
        raise SystemExit('No runs found under saved_models/*/*/*/')

    par, n_workers = parents_alive()
    ps_txt = '\n'.join(c for _, c in par)

    hdr = (f"{'dataset':<10} {'arch':<14} {'times':<10} {'phase':<9} {'progress':>11} "
           f"{'ckpts':>7} {'best nopush':>12} {'best push':>10} {'best ft':>9} {'alive':>6}")
    print(hdr)
    print('-' * len(hdr))

    for run in runs:
        parts = run.rstrip(os.sep).split(os.sep)
        ds, arch, times = parts[1], parts[2], parts[3]

        meta = {}
        mp = os.path.join('runs_meta', f'{ds}_{arch}_{times}.json')
        if os.path.exists(mp):
            try:
                meta = json.load(open(mp))
            except Exception:
                meta = {}
        tgt = meta.get('num_train_epochs')

        phase, progress = 'unknown', '-'
        log = os.path.join(run, 'train.log')
        if os.path.exists(log):
            txt = open(log, errors='ignore').read()
            eps = re.findall(r'epoch:\s*(\d+)', txt)
            its = re.findall(r'iteration:\s*(\d+)', txt)
            if eps:
                last = int(eps[-1])
                progress = f"{last + 1}/{tgt}" if tgt else f"epoch {last}"
                warm = meta.get('num_warm_epochs', 5)
                if tgt and last >= tgt - 1:
                    phase = 'DONE?'
                elif last < warm:
                    phase = 'warm'
                else:
                    phase = 'joint'
                # inside a push epoch the finetune loop logs iterations
                if its and txt.rfind('iteration:') > txt.rfind('epoch:'):
                    phase = 'finetune'
                    progress += f" ft{int(its[-1]) + 1}/20"

        cks = glob.glob(os.path.join(run, '*.pth'))
        n_bad = sum(1 for c in cks if os.path.isfile(c) and os.path.getsize(c) < MIN_VALID)

        def best(pred):
            vals = []
            for c in cks:
                b = os.path.basename(c)
                try:
                    if os.path.getsize(c) < MIN_VALID:
                        continue
                except OSError:
                    continue
                if not pred(b):
                    continue
                m = re.search(r'([01]\.\d{4})\.pth$', b)
                if m:
                    vals.append(float(m.group(1)))
            return f"{max(vals) * 100:.2f}%" if vals else '-'

        # families: '<e>nopush', '<e>push', '<e>_<i>push'
        b_nopush = best(lambda b: 'nopush' in b)
        b_ft = best(lambda b: '_' in b and b.split('_', 1)[1].lstrip('0123456789').startswith('push'))
        b_push = best(lambda b: 'nopush' not in b and 'push' in b
                      and not (('_' in b) and b.split('_', 1)[1].lstrip('0123456789').startswith('push')))

        done_marker = runner_said_complete(ds, arch, times)
        alive = 'YES' if (f'-dataset {ds}' in ps_txt and f'-times {times}' in ps_txt) else ''
        if done_marker and not alive:
            phase = 'DONE'
        elif phase == 'DONE?' and not alive:
            phase = 'DONE'

        ck_col = f"{len(cks)}" + (f"({n_bad}!)" if n_bad else "")
        print(f"{ds:<10} {arch:<14} {times:<10} {phase:<9} {progress:>11} {ck_col:>7} "
              f"{b_nopush:>12} {b_push:>10} {b_ft:>9} {alive:>6}")

    print()
    print(f"{len(par)} training run(s) active"
          + (f" (+{n_workers} DataLoader workers)" if n_workers else "") + ".")
    for pid, cmd in par:
        print('   ', pid, cmd[:100])
    print("\nphase key: DONE = finished (runner marker or last epoch reached, no process)")
    print("           DONE? = reached the last epoch but a process is still running")
    print("           finetune = inside a push epoch's 20 last-layer iterations")
    print("\nIf runs_meta/ is missing (run started before it existed), progress shows a bare")
    print("epoch number. The definitive check is:  grep -l TESNET_RUN_COMPLETE tn_*.log")


if __name__ == '__main__':
    main()
