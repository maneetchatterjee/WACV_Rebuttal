"""Keep only the best (and optionally the last) checkpoint per run; list the rest.

ProtoConcepts saves a checkpoint every epoch whenever accuracy clears PC_SAVE_TARGET_ACCU,
and each file is a whole pickled model (torch.save(obj=model)), not a state_dict -- roughly
350 MB for ViT-B/16 with 2000 prototypes. At the default target of 0.0 that means one file
per epoch, which adds up fast.

Dry run by default. Nothing is deleted unless you pass --delete.

    python3 prune_checkpoints.py                # show what would go
    python3 prune_checkpoints.py --delete       # actually remove
    python3 prune_checkpoints.py --keep-last --delete
"""
import argparse
import glob
import os
import re

FAMILIES = ('nofinetune', '_topk_finetuned')


MIN_VALID_BYTES = 1 << 20  # 1 MiB. A truncated .pth is worse than none: it looks like a
                           # result and fails at load time. Written when a disk fills.


def is_valid(path):
    try:
        return os.path.getsize(path) >= MIN_VALID_BYTES
    except OSError:
        return False


def accu_of(path):
    m = re.search(r'([01]\.\d{4})\.pth$', os.path.basename(path))
    return float(m.group(1)) if m else None


def epoch_of(path):
    m = re.match(r'^(\d+)', os.path.basename(path))
    return int(m.group(1)) if m else -1


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--delete', action='store_true', help='Actually delete. Default is dry run.')
    p.add_argument('--keep-last', action='store_true',
                   help='Also keep the highest-epoch checkpoint of each family.')
    a = p.parse_args()

    total_freed = 0
    total_kept = 0
    for run in sorted(glob.glob('saved_models/*/*/*/')):
        cks = glob.glob(os.path.join(run, '*.pth'))
        if not cks:
            continue
        keep = set()
        corrupt = [c for c in cks if not is_valid(c)]
        for fam in FAMILIES:
            fam_cks = [c for c in cks if fam in os.path.basename(c)]
            if not fam_cks:
                continue
            # Rank VALID files only. Ranking by filename accuracy alone will happily keep a
            # zero-byte file that a full disk truncated, and throw away the good ones.
            valid = [c for c in fam_cks if is_valid(c)]
            if not valid:
                print(f"  !! {fam}: no valid checkpoint in this family "
                      f"({len(fam_cks)} file(s), all truncated). Keeping nothing to delete.")
                continue
            keep.add(max(valid, key=lambda c: (accu_of(c) if accu_of(c) is not None else -1)))
            if a.keep_last:
                keep.add(max(valid, key=epoch_of))

        drop = [c for c in cks if c not in keep]
        freed = sum(os.path.getsize(c) for c in drop)
        kept_sz = sum(os.path.getsize(c) for c in keep)
        total_freed += freed
        total_kept += kept_sz

        print(f"\n{run}")
        print(f"  {len(cks)} checkpoints, {(freed+kept_sz)/2**30:.1f} GiB total")
        for c in sorted(keep):
            print(f"    KEEP  {os.path.basename(c)}  ({os.path.getsize(c)/2**20:.0f} MiB)")
        for c in sorted(corrupt):
            print(f"    corrupt -> delete  {os.path.basename(c)}  "
                  f"({os.path.getsize(c)} bytes)")
        print(f"    {'DELETE' if a.delete else 'would delete'} {len(drop)} files, "
              f"{freed/2**30:.1f} GiB")
        if a.delete:
            for c in drop:
                os.remove(c)

    print(f"\n{'Freed' if a.delete else 'Would free'}: {total_freed/2**30:.1f} GiB "
          f"| keeping {total_kept/2**30:.1f} GiB")
    if not a.delete:
        print("Dry run. Re-run with --delete to remove.")


if __name__ == '__main__':
    main()
