#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# TesNet (Wang et al., ICCV 2021) with a DINO ViT backbone.
#
#   DATASET=cub    bash run_tesnet_dino.sh
#   DATASET=gbcu   bash run_tesnet_dino.sh
#   DATASET=aid    bash run_tesnet_dino.sh
#   DATASET=car    bash run_tesnet_dino.sh
#   DATASET=flower bash run_tesnet_dino.sh
#
# Checkpoints: ./saved_models/<dataset>/<arch>/<times>/
#
# WARNING: main.py does shutil.rmtree(model_dir) on startup, so relaunching with the same
# DATASET/ARCH/TIMES DELETES the previous run. Change TIMES to keep an earlier run.
# ---------------------------------------------------------------------------
set -euo pipefail

DATASET="${DATASET:-cub}"
GPU="${GPU:-0}"
ARCH="${ARCH:-dino_vitb16}"
TIMES="${TIMES:-dino}"

case "$DATASET" in
  cub|CUB)              DS_TAG=cub;    DATA="${DATA_PATH:-/home/paul/Paul/DATASETS/CUB}" ;;
  gbcu|GBCU)            DS_TAG=gbcu;   DATA="${DATA_PATH:-/home/paul/Paul/DATASETS/GBCU}" ;;
  aid|AID)              DS_TAG=aid;    DATA="${DATA_PATH:-/home/paul/Paul/DATASETS/aid}" ;;
  car|CAR|cars|CARS)    DS_TAG=car;    DATA="${DATA_PATH:-/home/paul/Paul/DATASETS/car}" ;;
  flower|FLOWER|flowers) DS_TAG=flower; DATA="${DATA_PATH:-/home/paul/Paul/DATASETS/flower/flowers102_split}" ;;
  *)                    DS_TAG="$DATASET"; DATA="${DATA_PATH:?Set DATA_PATH for a custom dataset}" ;;
esac

# Class count is read off the tree, because num_prototypes must be an exact multiple of
# num_classes or model.py asserts. Upstream's fixed 2000 only works for 200 classes.
if [ ! -d "$DATA/train" ]; then
  echo "ERROR: $DATA/train does not exist. Check DATA_PATH." >&2
  exit 1
fi
DETECTED=$(find "$DATA/train" -mindepth 1 -maxdepth 1 -type d | wc -l)

export TN_DATA_PATH="$DATA"
export TN_NUM_CLASSES="${TN_NUM_CLASSES:-$DETECTED}"
export TN_ARCH="$ARCH"                     # settings needs this for the ViT lr default
export TN_LAYOUT="${TN_LAYOUT:-imagefolder}"
export TN_PROTOS_PER_CLASS="${TN_PROTOS_PER_CLASS:-10}"
export TN_IMG_SIZE="${TN_IMG_SIZE:-224}"
export TN_TRAIN_BATCH="${TN_TRAIN_BATCH:-48}"
export TN_TEST_BATCH="${TN_TEST_BATCH:-64}"
export TN_PUSH_BATCH="${TN_PUSH_BATCH:-48}"
export TN_EPOCHS="${TN_EPOCHS:-20}"
export TN_WARM_EPOCHS="${TN_WARM_EPOCHS:-5}"
export TN_PUSH_START="${TN_PUSH_START:-10}"
export TN_PUSH_EVERY="${TN_PUSH_EVERY:-10}"
export TN_LR_STEP="${TN_LR_STEP:-5}"
# 0.0 guarantees a checkpoint even on a hard dataset. util/save.py keeps only the best file
# per family, so this costs ~2 files, not one per epoch.
export TN_SAVE_TARGET_ACCU="${TN_SAVE_TARGET_ACCU:-0.0}"
export TN_RUN_NAME="$TIMES"

NPROTO=$(( TN_PROTOS_PER_CLASS * TN_NUM_CLASSES ))
echo "=============================================================="
echo " TesNet + DINO"
echo "   dataset     : $DS_TAG  ($DATA)"
echo "   classes     : $TN_NUM_CLASSES (detected from $DATA/train)"
echo "   basis concepts : $NPROTO  ($TN_PROTOS_PER_CLASS per class, depth ${TN_PROTO_DEPTH:-64})"
echo "   backbone    : $ARCH @ ${TN_IMG_SIZE}px"
echo "   epochs      : $TN_WARM_EPOCHS warm + $(( TN_EPOCHS - TN_WARM_EPOCHS )) joint, push from $TN_PUSH_START every $TN_PUSH_EVERY"
echo "   batch       : $TN_TRAIN_BATCH train / $TN_TEST_BATCH test / $TN_PUSH_BATCH push"
echo "   gpu         : $GPU"
echo "   checkpoints : ./saved_models/$DS_TAG/$ARCH/$TIMES/"
echo "=============================================================="

# Record the resolved config where main.py's shutil.rmtree(model_dir) cannot reach it, so
# status_tesnet.py can report progress against a target. main.py itself writes no such file
# and its copy of settings_CUB.py is environment-driven, so it shows no resolved values.
mkdir -p runs_meta
cat > "runs_meta/${DS_TAG}_${ARCH}_${TIMES}.json" <<EOF
{
  "dataset": "$DS_TAG", "arch": "$ARCH", "times": "$TIMES",
  "num_classes": $TN_NUM_CLASSES, "basis_concepts": $NPROTO,
  "img_size": $TN_IMG_SIZE, "train_batch": $TN_TRAIN_BATCH,
  "num_train_epochs": $TN_EPOCHS, "num_warm_epochs": $TN_WARM_EPOCHS,
  "push_start": $TN_PUSH_START, "push_every": $TN_PUSH_EVERY,
  "finetune_iters": 20,
  "save_target_accu": $TN_SAVE_TARGET_ACCU,
  "data_path": "$DATA"
}
EOF

python3 -u main.py -gpuid "$GPU" -arch "$ARCH" -dataset "$DS_TAG" -times "$TIMES"
echo "TESNET_RUN_COMPLETE $DS_TAG $ARCH $TIMES"

echo "Finished. Results in ./saved_models/$DS_TAG/$ARCH/$TIMES/"
echo "  training log : ./saved_models/$DS_TAG/$ARCH/$TIMES/train.log"
echo "  checkpoints  : ./saved_models/$DS_TAG/$ARCH/$TIMES/*.pth"
echo "  prototypes   : ./saved_models/$DS_TAG/$ARCH/$TIMES/img/"
