import argparse
import glob
import os
import re

MIN_VALID_BYTES = 1 << 20


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--load', action='store_true',
                   help='Actually torch.load each checkpoint. Slow but conclusive.')
    p.add_argument('--pattern', default='saved_models/*/*/*/*.pth')
    a = p.parse_args()

    files = sorted(glob.glob(a.pattern))
    if not files:
        raise SystemExit(f"No checkpoints matched {a.pattern}")

    bad, ok = [], []
    print(f"{'checkpoint':<62} {'MiB':>7} {'status':<12} {'detail'}")
    print('-' * 110)
    vanished = []
    for f in files:
        try:
            size = os.path.getsize(f)
        except OSError:
            # A run is still training and save.py pruned this file after our glob. Not an
            # error: the checkpoint was superseded by a better one.
            vanished.append(f)
            continue
        rel = os.sep.join(f.split(os.sep)[1:])
        detail = ''
        if size < MIN_VALID_BYTES:
            status = 'CORRUPT'
            detail = 'truncated (disk full during save)'
            bad.append(f)
        elif not a.load:
            status = 'size-ok'
        else:
            try:
                import torch
                obj = torch.load(f, map_location='cpu', weights_only=False)
                nproto = getattr(obj, 'num_prototypes', None)
                ncls = getattr(obj, 'num_classes', None)
                if nproto is None:
                    detail = type(obj).__name__
                else:
                    detail = f"{ncls} classes, {nproto} prototypes"
                    w = getattr(obj, 'last_layer', None)
                    if w is not None and hasattr(w, 'weight'):
                        detail += f", last_layer {tuple(w.weight.shape)}"
                status = 'LOADS'
                ok.append(f)
                del obj
            except Exception as e:
                status = 'LOAD FAIL'
                detail = f"{type(e).__name__}: {str(e)[:50]}"
                bad.append(f)
        print(f"{rel:<62} {size/2**20:>7.0f} {status:<12} {detail}")

    print()
    if vanished:
        print(f"{len(vanished)} checkpoint(s) disappeared mid-scan (a live run superseded "
              f"them). Re-run this once training finishes for a clean picture:")
        for f in vanished:
            print('   ', os.path.basename(f))
        print()
    if bad:
        print(f"{len(bad)} unusable checkpoint(s):")
        for f in bad:
            print('   ', f)
        print("\nDelete them:  python3 prune_checkpoints.py --delete")
        print("If a dataset has NO usable checkpoint left, that run must be redone.")
    else:
        print("All checkpoints usable." + ('' if a.load else '  (size check only; add --load to be sure)'))

    # which datasets still have a usable model
    print("\nusable checkpoints per dataset:")
    per = {}
    for f in files:
        if f in bad or f in vanished:
            continue
        ds = f.split(os.sep)[1]
        per.setdefault(ds, []).append(os.path.basename(f))
    for ds in sorted(set(x.split(os.sep)[1] for x in files)):
        got = per.get(ds, [])
        mark = '' if got else '   <-- NOTHING USABLE, rerun needed'
        print(f"   {ds:<10} {len(got)}{mark}")
        for g in sorted(got):
            print(f"        {g}")


if __name__ == '__main__':
    main()
